<?php
include '../includes/auth.php';
require_once '../config/db.php';

// Ensure UTF-8 encoding for the database connection
$pdo->exec("SET NAMES 'utf8mb4' COLLATE 'utf8mb4_unicode_ci'");

$user_id = $_SESSION['user_id'];
$name = $_SESSION['name'] ?? '';

// Function to safely render notification messages with <strong> tags
function renderSafeMessage($message) {
    // Allow only <strong> tags, strip others, and ensure UTF-8 encoding
    return strip_tags($message, '<strong>');
}

// Mark as read if requested
if (isset($_GET['mark']) && is_numeric($_GET['mark'])) {
    $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?");
    $stmt->execute([$_GET['mark'], $user_id]);
    header("Location: index.php");
    exit;
}

// Mark all as read
if (isset($_GET['mark_all'])) {
    $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0");
    $stmt->execute([$user_id]);
    header("Location: index.php");
    exit;
}

// Fetch all notifications
$stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC");
$stmt->execute([$user_id]);
$notifications = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Notifications - Focal</title>
    <style>
        :root {
            --bg-primary: #fefcf8;
            --bg-secondary: #ffffff;
            --bg-card: #ffffff;
            --bg-hover: #f8f6f2;
            --border-color: #e8e4df;
            --text-primary: #2d2d2d;
            --text-secondary: #6b6b6b;
            --text-muted: #9a9a9a;
            --accent-primary: #ff6314;
            --accent-secondary: #5296dd;
            --accent-hover: #ff5722;
            --success: #22c55e;
            --warning: #f59e0b;
            --gradient: linear-gradient(135deg, #ff6314 0%, #5296dd 100%);
            --warm-orange: #ffaa7a;
            --warm-yellow: #ffeaa7;
            --warm-cream: #fff8f0;
            --shadow-soft: 0 4px 12px rgba(255, 99, 20, 0.1);
            --shadow-hover: 0 8px 24px rgba(255, 99, 20, 0.2);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Helvetica Neue', sans-serif;
            background: radial-gradient(circle at center, var(--warm-cream) 0%, var(--bg-primary) 100%);
            color: var(--text-primary);
            line-height: 1.6;
            min-height: 100vh;
            overflow-x: hidden;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 24px;
        }

        /* Header */
        .header {
            background: rgba(255, 255, 255, 0.95);
            border-bottom: 1px solid var(--border-color);
            padding: 16px 0;
            position: sticky;
            top: 0;
            z-index: 1000;
            backdrop-filter: blur(20px);
            box-shadow: var(--shadow-soft);
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 28px;
            font-weight: 700;
            background: var(--gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .breadcrumb {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
            color: var(--text-secondary);
        }

        .breadcrumb a {
            color: var(--accent-secondary);
            text-decoration: none;
        }

        .breadcrumb a:hover {
            text-decoration: underline;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--gradient);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 16px;
            box-shadow: var(--shadow-soft);
        }

        /* Main Content */
        .main-content {
            display: flex;
            gap: 24px;
            padding: 32px 0;
            position: relative;
        }

        .feed {
            flex: 1;
            display: flex;
            flex-direction: column;
            gap: 24px;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            flex-shrink: 0;
            transition: transform 0.3s ease;
            position: fixed;
            top: 88px;
            right: 0;
            height: calc(100vh - 88px);
            background: var(--bg-card);
            border-left: 1px solid var(--border-color);
            transform: translateX(100%);
            z-index: 900;
        }

        .sidebar.open {
            transform: translateX(0);
        }

        .sidebar-toggle {
            position: fixed;
            top: 100px;
            right: 20px;
            background: var(--gradient);
            color: white;
            border: none;
            border-radius: 50%;
            width: 48px;
            height: 48px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            box-shadow: var(--shadow-soft);
            transition: all 0.3s ease;
            z-index: 950;
        }

        .sidebar-toggle:hover {
            transform: scale(1.1);
            box-shadow: var(--shadow-hover);
        }

        /* Notifications */
        .notification-feed {
            background: var(--bg-card);
            border-radius: 16px;
            box-shadow: var(--shadow-soft);
            overflow: hidden;
            max-height: 600px;
            overflow-y: auto;
            position: relative;
        }

        .notification-header {
            padding: 16px 24px;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: var(--warm-cream);
        }

        .notification-title {
            font-size: 20px;
            font-weight: 600;
            color: var(--text-primary);
        }

        .mark-all-btn {
            background: var(--gradient);
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
            box-shadow: var(--shadow-soft);
        }

        .mark-all-btn:hover {
            transform: scale(1.05);
            box-shadow: var(--shadow-hover);
        }

        .notification-item {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            padding: 16px 24px;
            border-bottom: 1px solid var(--border-color);
            transition: all 0.3s ease;
            transform: translateZ(0);
        }

        .notification-item:hover {
            background: var(--bg-hover);
            transform: translateY(-2px) translateZ(10px);
        }

        .notification-item.unread {
            background: rgba(255, 99, 20, 0.05);
        }

        .notification-item:last-child {
            border-bottom: none;
        }

        .notification-dot {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: var(--gradient);
            margin-top: 6px;
            flex-shrink: 0;
            box-shadow: 0 2px 4px rgba(255, 99, 20, 0.3);
            opacity: 0.3;
        }

        .notification-item.unread .notification-dot {
            opacity: 1;
        }

        .notification-content {
            flex: 1;
        }

        .notification-message {
            font-size: 15px;
            color: var(--text-primary);
            margin-bottom: 4px;
        }

        .notification-message a {
            color: var(--accent-secondary);
            text-decoration: none;
            font-weight: 500;
        }

        .notification-message a:hover {
            text-decoration: underline;
        }

        .notification-time {
            font-size: 13px;
            color: var(--text-muted);
        }

        .notification-action {
            font-size: 14px;
            color: var(--accent-primary);
            text-decoration: none;
            font-weight: 500;
        }

        .notification-action:hover {
            text-decoration: underline;
        }

        /* Sidebar Widgets */
        .widget {
            background: var(--bg-card);
            border-radius: 12px;
            margin-bottom: 16px;
            box-shadow: var(--shadow-soft);
            overflow: hidden;
        }

        .widget-header {
            padding: 16px;
            border-bottom: 1px solid var(--border-color);
            font-weight: 600;
            font-size: 15px;
            color: var(--text-primary);
            background: var(--warm-cream);
        }

        .widget-content {
            padding: 16px;
        }

        .quick-actions {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .quick-action {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
            border-radius: 8px;
            background: var(--warm-cream);
            border: 1px solid var(--border-color);
            text-decoration: none;
            color: var(--text-primary);
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .quick-action:hover {
            background: var(--warm-yellow);
            border-color: var(--warm-orange);
            transform: translateX(4px);
            box-shadow: var(--shadow-hover);
        }

        .logout-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 20px;
            background: var(--gradient);
            border: none;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s ease;
            margin-top: 16px;
            box-shadow: var(--shadow-soft);
            width: 100%;
            text-align: center;
        }

        .logout-btn:hover {
            transform: scale(1.05);
            box-shadow: var(--shadow-hover);
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 48px 20px;
            color: var(--text-muted);
        }

        .empty-state-icon {
            font-size: 56px;
            margin-bottom: 16px;
            opacity: 0.5;
        }

        /* Responsive */
        @media (max-width: 1024px) {
            .sidebar {
                width: 240px;
            }
        }

        @media (max-width: 768px) {
            .main-content {
                flex-direction: column;
            }

            .sidebar {
                position: fixed;
                width: 100%;
                height: calc(100vh - 88px);
                top: 88px;
                right: 0;
                transform: translateX(100%);
            }

            .sidebar.open {
                transform: translateX(0);
            }
        }

        @media (max-width: 480px) {
            .container {
                padding: 0 16px;
            }

            .notification-header {
                flex-direction: column;
                gap: 12px;
                align-items: flex-start;
            }

            .mark-all-btn {
                width: 100%;
                text-align: center;
            }
        }

        /* Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: var(--warm-cream);
        }

        ::-webkit-scrollbar-thumb {
            background: var(--warm-orange);
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: var(--accent-primary);
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="header-content">
                <div class="logo">Focal</div>
                <div class="breadcrumb">
                    <a href="../dashboard/home.php">Dashboard</a>
                    <span>→</span>
                    <span>Notifications</span>
                </div>
                <div class="user-info">
                    <div class="user-avatar"><?= strtoupper(substr($name, 0, 1)) ?></div>
                </div>
            </div>
        </div>
    </header>

    <button class="sidebar-toggle" aria-label="Toggle Sidebar">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2">
            <path d="M4 6h16M4 12h16M4 18h16"/>
        </svg>
    </button>

    <div class="container">
        <div class="main-content">
            <main class="feed">
                <div class="notification-feed">
                    <div class="notification-header">
                        <h2 class="notification-title">Notifications (<?= count($notifications) ?>)</h2>
                        <?php if (count($notifications) > 0): ?>
                            <a href="?mark_all=1" class="mark-all-btn">Mark All as Read</a>
                        <?php endif; ?>
                    </div>
                    <div class="notification-content">
                        <?php if (count($notifications) > 0): ?>
                            <?php foreach ($notifications as $note): ?>
                                <div class="notification-item <?= $note['is_read'] ? '' : 'unread' ?>">
                                    <div class="notification-dot"></div>
                                    <div class="notification-content">
                                        <div class="notification-message">
                                            <?php if (!empty($note['link'])): ?>
                                                <a href="<?= htmlspecialchars($note['link'], ENT_QUOTES, 'UTF-8') ?>"><?= renderSafeMessage($note['message']) ?></a>
                                            <?php else: ?>
                                                <?= renderSafeMessage($note['message']) ?>
                                            <?php endif; ?>
                                        </div>
                                        <div class="notification-time"><?= date('M j, Y \a\t g:i A', strtotime($note['created_at'])) ?></div>
                                        <?php if (!$note['is_read']): ?>
                                            <a href="?mark=<?= $note['id'] ?>" class="notification-action">Mark as Read</a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="empty-state">
                                <div class="empty-state-icon">📭</div>
                                <h3>No notifications yet</h3>
                                <p>You're all caught up!</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </main>

            <aside class="sidebar">
                <div class="widget">
                    <div class="widget-header">Quick Actions</div>
                    <div class="widget-content">
                        <div class="quick-actions">
                            <a href="../dashboard/projects.php?action=new" class="quick-action">
                                <span>➕</span>
                                <span>New Project</span>
                            </a>
                            <a href="../dashboard/tasks.php?action=new" class="quick-action">
                                <span>📝</span>
                                <span>Add Task</span>
                            </a>
                            <a href="../dashboard/files.php?action=upload" class="quick-action">
                                <span>📤</span>
                                <span>Upload File</span>
                            </a>
                            <a href="../dashboard/settings.php" class="quick-action">
                                <span>⚙️</span>
                                <span>Settings</span>
                            </a>
                        </div>
                        <a class="logout-btn" href="../logout.php">
                            <span>🚪</span>
                            <span>Logout</span>
                        </a>
                    </div>
                </div>
            </aside>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Sidebar toggle
            const sidebar = document.querySelector('.sidebar');
            const toggleButton = document.querySelector('.sidebar-toggle');
            toggleButton.addEventListener('click', () => {
                sidebar.classList.toggle('open');
                toggleButton.innerHTML = sidebar.classList.contains('open')
                    ? '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2"><path d="M6 18L18 6M6 6l12 12"/></svg>'
                    : '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2"><path d="M4 6h16M4 12h16M4 18h16"/></svg>';
            });

            // Animate notifications
            const notificationItems = document.querySelectorAll('.notification-item');
            notificationItems.forEach((item, index) => {
                item.style.opacity = '0';
                item.style.transform = 'translateY(20px)';
                setTimeout(() => {
                    item.style.transition = 'all 0.4s ease';
                    item.style.opacity = '1';
                    item.style.transform = 'translateY(0)';
                }, index * 100);
            });

            // Mark as read animation
            const markLinks = document.querySelectorAll('.notification-action');
            markLinks.forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    const item = this.closest('.notification-item');
                    item.style.transition = 'all 0.3s ease';
                    item.style.opacity = '0.3';
                    setTimeout(() => {
                        window.location.href = this.href;
                    }, 300);
                });
            });

            // Parallax effect for notifications
            const notificationFeed = document.querySelector('.notification-feed');
            notificationFeed.addEventListener('scroll', () => {
                const items = notificationFeed.querySelectorAll('.notification-item');
                items.forEach(item => {
                    const rect = item.getBoundingClientRect();
                    const offset = rect.top / window.innerHeight;
                    item.style.transform = `translateZ(${offset * 20}px)`;
                });
            });
        });
    </script>
</body>
</html>