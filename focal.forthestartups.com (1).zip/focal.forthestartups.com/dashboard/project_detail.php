<?php
include '../includes/auth.php';
require_once '../config/db.php';

$user_id = $_SESSION['user_id'];
$name = $_SESSION['name'] ?? '';

$project_id = $_GET['id'] ?? null;

if (!$project_id) {
    die("Project ID is missing.");
}

// Fetch the project details
$stmt = $pdo->prepare("SELECT * FROM projects WHERE id = ? AND user_id = ?");
$stmt->execute([$project_id, $user_id]);
$project = $stmt->fetch();

if (!$project) {
    die("Project not found or access denied.");
}

// Fetch tasks linked to this project
$stmt = $pdo->prepare("SELECT * FROM tasks WHERE project_id = ? ORDER BY created_at DESC");
$stmt->execute([$project_id]);
$tasks = $stmt->fetchAll();

// Calculate project statistics
$total_tasks = count($tasks);
$completed_tasks = count(array_filter($tasks, fn($t) => $t['status'] === 'completed'));
$in_progress_tasks = count(array_filter($tasks, fn($t) => $t['status'] === 'in_progress'));
$pending_tasks = count(array_filter($tasks, fn($t) => $t['status'] === 'pending'));
$progress_percentage = $total_tasks > 0 ? round(($completed_tasks / $total_tasks) * 100) : 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($project['title']) ?> - Focal</title>
  <style>
    :root {
      --bg-primary: #fefcf8;
      --bg-secondary: #ffffff;
      --bg-card: #ffffff;
      --bg-hover: #f8f6f2;
      --border-color: #e8e4df;
      --text-primary: #2d2d2d;
      --text-secondary: #6b6b6b;
      --text-muted: #9a9a9a;
      --accent-primary: #ff6314;
      --accent-secondary: #5296dd;
      --accent-hover: #ff5722;
      --success: #22c55e;
      --warning: #f59e0b;
      --pending: #94a3b8;
      --gradient: linear-gradient(135deg, #ff6314 0%, #5296dd 100%);
      --warm-orange: #ffaa7a;
      --warm-yellow: #ffeaa7;
      --warm-cream: #fff8f0;
      --shadow-soft: 0 2px 8px rgba(255, 99, 20, 0.08);
      --shadow-hover: 0 8px 24px rgba(255, 99, 20, 0.15);
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Helvetica Neue', sans-serif;
      background: linear-gradient(135deg, var(--warm-cream) 0%, var(--bg-primary) 100%);
      color: var(--text-primary);
      line-height: 1.6;
      min-height: 100vh;
    }

    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 16px;
    }

    /* Header */
    .header {
      background: rgba(255, 255, 255, 0.95);
      border-bottom: 1px solid var(--border-color);
      padding: 16px 0;
      position: sticky;
      top: 0;
      z-index: 100;
      backdrop-filter: blur(20px);
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
    }

    .header-content {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .logo {
      font-size: 24px;
      font-weight: 700;
      background: var(--gradient);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
      text-decoration: none;
    }

    .breadcrumb {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 14px;
      color: var(--text-secondary);
    }

    .breadcrumb a {
      color: var(--accent-secondary);
      text-decoration: none;
    }

    .breadcrumb a:hover {
      text-decoration: underline;
    }

    .user-info {
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .user-avatar {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      background: var(--gradient);
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 600;
      font-size: 14px;
      color: white;
    }

    /* Main Content */
    .main-content {
      display: grid;
      grid-template-columns: 1fr 350px;
      gap: 24px;
      padding: 24px 0;
    }

    .content {
      display: flex;
      flex-direction: column;
      gap: 24px;
    }

    .sidebar {
      position: sticky;
      top: 88px;
      height: fit-content;
    }

    /* Cards */
    .card {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: 12px;
      overflow: hidden;
      transition: all 0.3s ease;
      box-shadow: var(--shadow-soft);
    }

    .card:hover {
      border-color: var(--warm-orange);
      box-shadow: var(--shadow-hover);
      transform: translateY(-1px);
    }

    .card-header {
      padding: 20px 24px;
      border-bottom: 1px solid var(--border-color);
      background: var(--warm-cream);
    }

    .card-title {
      font-size: 20px;
      font-weight: 600;
      color: var(--text-primary);
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .card-content {
      padding: 24px;
    }

    /* Project Hero */
    .project-hero {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: 12px;
      overflow: hidden;
      box-shadow: var(--shadow-soft);
      position: relative;
    }

    .project-hero::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 4px;
      background: var(--gradient);
    }

    .project-hero-content {
      padding: 32px 24px;
    }

    .project-title {
      font-size: 32px;
      font-weight: 700;
      color: var(--text-primary);
      margin-bottom: 12px;
      line-height: 1.2;
    }

    .project-description {
      font-size: 16px;
      color: var(--text-secondary);
      line-height: 1.6;
      margin-bottom: 20px;
    }

    .project-meta {
      display: flex;
      flex-wrap: wrap;
      gap: 20px;
      font-size: 14px;
      color: var(--text-muted);
    }

    .project-meta-item {
      display: flex;
      align-items: center;
      gap: 6px;
    }

    /* Progress Section */
    .progress-section {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 20px 24px;
      background: var(--warm-cream);
      border-top: 1px solid var(--border-color);
    }

    .progress-info {
      display: flex;
      align-items: center;
      gap: 16px;
    }

    .progress-circle {
      position: relative;
      width: 60px;
      height: 60px;
    }

    .progress-circle svg {
      transform: rotate(-90deg);
    }

    .progress-circle .bg-circle {
      fill: none;
      stroke: var(--border-color);
      stroke-width: 4;
    }

    .progress-circle .progress-ring {
      fill: none;
      stroke: url(#gradient);
      stroke-width: 4;
      stroke-linecap: round;
      transition: stroke-dasharray 0.5s ease;
    }

    .progress-text {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      font-weight: 700;
      font-size: 14px;
      color: var(--text-primary);
    }

    .progress-details h4 {
      font-size: 18px;
      color: var(--text-primary);
      margin-bottom: 4px;
    }

    .progress-details p {
      font-size: 14px;
      color: var(--text-secondary);
    }

    /* Stats Grid */
    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
      gap: 16px;
    }

    .stat-card {
      background: var(--warm-cream);
      padding: 20px;
      border-radius: 10px;
      text-align: center;
      border: 1px solid var(--border-color);
      transition: all 0.2s ease;
    }

    .stat-card:hover {
      transform: translateY(-2px);
      box-shadow: var(--shadow-soft);
    }

    .stat-number {
      font-size: 24px;
      font-weight: 700;
      margin-bottom: 4px;
    }

    .stat-number.pending { color: var(--pending); }
    .stat-number.in-progress { color: var(--warning); }
    .stat-number.completed { color: var(--success); }
    .stat-number.total { 
      background: var(--gradient);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }

    .stat-label {
      font-size: 12px;
      color: var(--text-secondary);
      text-transform: uppercase;
      font-weight: 600;
      letter-spacing: 0.5px;
    }

    /* Task List */
    .task-list {
      display: flex;
      flex-direction: column;
      gap: 12px;
    }

    .task-item {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: 8px;
      padding: 16px;
      transition: all 0.2s ease;
      position: relative;
    }

    .task-item:hover {
      transform: translateY(-1px);
      box-shadow: var(--shadow-soft);
    }

    .task-item::before {
      content: '';
      position: absolute;
      left: 0;
      top: 0;
      bottom: 0;
      width: 3px;
      border-radius: 8px 0 0 8px;
    }

    .task-item.status-pending::before { background: var(--pending); }
    .task-item.status-in_progress::before { background: var(--warning); }
    .task-item.status-completed::before { background: var(--success); }

    .task-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 8px;
    }

    .task-title {
      font-size: 16px;
      font-weight: 600;
      color: var(--text-primary);
    }

    .task-status {
      padding: 4px 8px;
      border-radius: 12px;
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .task-status.pending {
      background: rgba(148, 163, 184, 0.15);
      color: var(--pending);
    }

    .task-status.in_progress {
      background: rgba(245, 158, 11, 0.15);
      color: var(--warning);
    }

    .task-status.completed {
      background: rgba(34, 197, 94, 0.15);
      color: var(--success);
    }

    .task-meta {
      display: flex;
      gap: 16px;
      font-size: 13px;
      color: var(--text-muted);
    }

    .task-meta-item {
      display: flex;
      align-items: center;
      gap: 4px;
    }

    /* Empty State */
    .empty-state {
      text-align: center;
      padding: 60px 20px;
      color: var(--text-muted);
    }

    .empty-state-icon {
      font-size: 64px;
      margin-bottom: 16px;
      opacity: 0.5;
    }

    .empty-state h3 {
      font-size: 20px;
      margin-bottom: 8px;
      color: var(--text-secondary);
    }

    .empty-state p {
      font-size: 16px;
      margin-bottom: 24px;
    }

    /* Back Button */
    .back-button {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 12px 20px;
      background: var(--gradient);
      color: white;
      text-decoration: none;
      border-radius: 8px;
      font-weight: 600;
      font-size: 14px;
      transition: all 0.2s ease;
      box-shadow: 0 2px 8px rgba(255, 99, 20, 0.3);
    }

    .back-button:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(255, 99, 20, 0.4);
      text-decoration: none;
    }

    /* Responsive */
    @media (max-width: 768px) {
      .main-content {
        grid-template-columns: 1fr;
      }
      
      .sidebar {
        position: static;
        order: -1;
      }

      .project-title {
        font-size: 24px;
      }

      .stats-grid {
        grid-template-columns: repeat(2, 1fr);
      }

      .progress-section {
        flex-direction: column;
        gap: 16px;
        text-align: center;
      }
    }

    @media (max-width: 480px) {
      .container {
        padding: 0 12px;
      }
      
      .stats-grid {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>
  <header class="header">
    <div class="container">
      <div class="header-content">
        <a href="home.php" class="logo">Focal</a>
        <div class="breadcrumb">
          <a href="home.php">Dashboard</a>
          <span>→</span>
          <a href="projects.php">Projects</a>
          <span>→</span>
          <span><?= htmlspecialchars($project['title']) ?></span>
        </div>
        <div class="user-info">
          <div class="user-avatar"><?= strtoupper(substr($name, 0, 1)) ?></div>
        </div>
      </div>
    </div>
  </header>

  <div class="container">
    <div class="main-content">
      <main class="content">
        <!-- Project Hero Section -->
        <div class="project-hero">
          <div class="project-hero-content">
            <h1 class="project-title"><?= htmlspecialchars($project['title']) ?></h1>
            <p class="project-description">
              <?= !empty($project['description']) ? nl2br(htmlspecialchars($project['description'])) : '<em style="color: var(--text-muted);">No description provided for this project.</em>' ?>
            </p>
            <div class="project-meta">
              <div class="project-meta-item">
                <span>📅</span>
                <span>Created <?= date('F j, Y', strtotime($project['created_at'])) ?></span>
              </div>
              <div class="project-meta-item">
                <span>🆔</span>
                <span>Project ID: <?= $project['id'] ?></span>
              </div>
              <div class="project-meta-item">
                <span>📝</span>
                <span><?= $total_tasks ?> total tasks</span>
              </div>
            </div>
          </div>
          
          <div class="progress-section">
            <div class="progress-info">
              <div class="progress-circle">
                <svg width="60" height="60" viewBox="0 0 60 60">
                  <defs>
                    <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" style="stop-color:#ff6314"/>
                      <stop offset="100%" style="stop-color:#5296dd"/>
                    </linearGradient>
                  </defs>
                  <circle class="bg-circle" cx="30" cy="30" r="26"/>
                  <circle class="progress-ring" cx="30" cy="30" r="26" 
                          stroke-dasharray="<?= ($progress_percentage / 100) * 163.36 ?> 163.36"/>
                </svg>
                <div class="progress-text"><?= $progress_percentage ?>%</div>
              </div>
              <div class="progress-details">
                <h4>Project Progress</h4>
                <p><?= $completed_tasks ?> of <?= $total_tasks ?> tasks completed</p>
              </div>
            </div>
            <a href="tasks.php?project=<?= $project_id ?>" class="back-button">
              <span>➕</span>
              <span>Add Task</span>
            </a>
          </div>
        </div>

        <!-- Tasks Section -->
        <div class="card">
          <div class="card-header">
            <h2 class="card-title">✅ Project Tasks (<?= $total_tasks ?>)</h2>
          </div>
          <div class="card-content">
            <?php if ($total_tasks > 0): ?>
              <div class="task-list">
                <?php foreach ($tasks as $task): ?>
                  <div class="task-item status-<?= $task['status'] ?>">
                    <div class="task-header">
                      <h3 class="task-title"><?= htmlspecialchars($task['title']) ?></h3>
                      <span class="task-status <?= $task['status'] ?>">
                        <?= ucfirst(str_replace('_', ' ', $task['status'])) ?>
                      </span>
                    </div>
                    <div class="task-meta">
                      <div class="task-meta-item">
                        <span>📅</span>
                        <span>Created <?= date('M j, Y', strtotime($task['created_at'])) ?></span>
                      </div>
                      <?php if ($task['due_date']): ?>
                        <div class="task-meta-item">
                          <span>⏰</span>
                          <span>Due <?= date('M j, Y', strtotime($task['due_date'])) ?></span>
                        </div>
                      <?php endif; ?>
                    </div>
                  </div>
                <?php endforeach; ?>
              </div>
            <?php else: ?>
              <div class="empty-state">
                <div class="empty-state-icon">📝</div>
                <h3>No tasks yet</h3>
                <p>This project doesn't have any tasks yet. Create your first task to get started!</p>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </main>

      <aside class="sidebar">
        <!-- Project Stats -->
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">📊 Task Overview</h3>
          </div>
          <div class="card-content">
            <div class="stats-grid">
              <div class="stat-card">
                <div class="stat-number total"><?= $total_tasks ?></div>
                <div class="stat-label">Total</div>
              </div>
              <div class="stat-card">
                <div class="stat-number pending"><?= $pending_tasks ?></div>
                <div class="stat-label">Pending</div>
              </div>
              <div class="stat-card">
                <div class="stat-number in-progress"><?= $in_progress_tasks ?></div>
                <div class="stat-label">In Progress</div>
              </div>
              <div class="stat-card">
                <div class="stat-number completed"><?= $completed_tasks ?></div>
                <div class="stat-label">Completed</div>
              </div>
            </div>
          </div>
        </div>

        <!-- Quick Actions -->
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">⚡ Quick Actions</h3>
          </div>
          <div class="card-content">
            <div style="display: flex; flex-direction: column; gap: 12px;">
              <a href="tasks.php?project=<?= $project_id ?>" style="display: flex; align-items: center; gap: 8px; padding: 12px; background: var(--warm-cream); border-radius: 8px; text-decoration: none; color: var(--text-primary); font-weight: 500; transition: all 0.2s ease;" onmouseover="this.style.background='var(--warm-yellow)'" onmouseout="this.style.background='var(--warm-cream)'">
                <span>📝</span>
                <span>Add New Task</span>
              </a>
              <a href="projects.php" style="display: flex; align-items: center; gap: 8px; padding: 12px; background: var(--warm-cream); border-radius: 8px; text-decoration: none; color: var(--text-primary); font-weight: 500; transition: all 0.2s ease;" onmouseover="this.style.background='var(--warm-yellow)'" onmouseout="this.style.background='var(--warm-cream)'">
                <span>📁</span>
                <span>All Projects</span>
              </a>
              <a href="home.php" style="display: flex; align-items: center; gap: 8px; padding: 12px; background: var(--warm-cream); border-radius: 8px; text-decoration: none; color: var(--text-primary); font-weight: 500; transition: all 0.2s ease;" onmouseover="this.style.background='var(--warm-yellow)'" onmouseout="this.style.background='var(--warm-cream)'">
                <span>🏠</span>
                <span>Dashboard</span>
              </a>
            </div>
          </div>
        </div>
      </aside>
    </div>
  </div>

  <script>
    // Animate elements on load
    document.addEventListener('DOMContentLoaded', function() {
      // Animate task items
      const taskItems = document.querySelectorAll('.task-item');
      taskItems.forEach((item, index) => {
        item.style.opacity = '0';
        item.style.transform = 'translateY(20px)';
        setTimeout(() => {
          item.style.transition = 'all 0.4s ease';
          item.style.opacity = '1';
          item.style.transform = 'translateY(0)';
        }, index * 100);
      });

      // Animate progress circle
      const progressRing = document.querySelector('.progress-ring');
      if (progressRing) {
        setTimeout(() => {
          progressRing.style.transition = 'stroke-dasharray 1s ease-in-out';
        }, 500);
      }

      // Animate stat cards
      const statCards = document.querySelectorAll('.stat-card');
      statCards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'scale(0.9)';
        setTimeout(() => {
          card.style.transition = 'all 0.3s ease';
          card.style.opacity = '1';
          card.style.transform = 'scale(1)';
        }, 200 + (index * 50));
      });
    });

    // Add click feedback to task items
    document.querySelectorAll('.task-item').forEach(item => {
      item.addEventListener('click', function() {
        this.style.transform = 'scale(0.98)';
        setTimeout(() => {
          this.style.transform = 'translateY(-1px)';
        }, 100);
      });
    });
  </script>
</body>
</html>