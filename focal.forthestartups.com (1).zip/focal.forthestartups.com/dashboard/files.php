<?php
include '../includes/auth.php';
require_once '../config/db.php';

$user_id = $_SESSION['user_id'];
$name = $_SESSION['name'] ?? '';

// Handle new file/link upload
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $project_id = $_POST['project_id'];
    $type = $_POST['file_type'];
    $name = $_POST['file_name'];

    if ($type === 'link') {
        $url = $_POST['file_url'];
    } else {
        $upload_dir = '../assets/uploads/';
        $filename = basename($_FILES['file_upload']['name']);
        $filepath = $upload_dir . time() . '_' . $filename;

        if (move_uploaded_file($_FILES['file_upload']['tmp_name'], $filepath)) {
            $url = $filepath;
        } else {
            die("Upload failed.");
        }
    }

    $stmt = $pdo->prepare("INSERT INTO project_files (project_id, file_type, file_name, file_url, uploaded_by) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$project_id, $type, $name, $url, $user_id]);

    // Add notification for file/link upload
    $safe_name = htmlspecialchars($name);
    addNotification(
        $pdo,
        $user_id,
        "📂 New file/link added: <strong>$safe_name</strong>",
        "files.php"
    );

    header("Location: files.php");
    exit;
}

// Fetch user's projects and files
$projects = $pdo->prepare("SELECT * FROM projects WHERE user_id = ?");
$projects->execute([$user_id]);
$projects = $projects->fetchAll();

$files = $pdo->prepare("
    SELECT pf.*, p.title AS project_title 
    FROM project_files pf 
    JOIN projects p ON pf.project_id = p.id 
    WHERE p.user_id = ? 
    ORDER BY pf.uploaded_at DESC
");
$files->execute([$user_id]);
$files = $files->fetchAll();

// Helper: detect file/link type icon
function getFileIcon($file) {
    $url = strtolower($file['file_url']);
    if ($file['file_type'] === 'link') {
        // Productivity & Collaboration Tools
        if (strpos($url, 'notion.so') !== false) {
            return '<img src="https://www.notion.so/images/favicon.ico" alt="Notion" class="file-icon"> Notion';
        }
        if (strpos($url, 'docs.google.com') !== false) {
            return '<img src="https://img.icons8.com/color/48/000000/google-docs.png" alt="Google Doc" class="file-icon"> Google Doc';
        }
        if (strpos($url, 'sheets.google.com') !== false) {
            return '<img src="https://img.icons8.com/color/48/000000/google-sheets.png" alt="Google Sheet" class="file-icon"> Google Sheet';
        }
        if (strpos($url, 'slides.google.com') !== false) {
            return '<img src="https://img.icons8.com/color/48/000000/google-slides.png" alt="Google Slides" class="file-icon"> Google Slides';
        }
        if (strpos($url, 'drive.google.com') !== false) {
            return '<img src="https://img.icons8.com/color/48/000000/google-drive.png" alt="Google Drive" class="file-icon"> Google Drive';
        }
        
        // Design & Creative Tools
        if (strpos($url, 'canva.com') !== false) {
            return '<img src="https://static.canva.com/static/images/favicon.ico" alt="Canva" class="file-icon"> Canva';
        }
        if (strpos($url, 'adobe.com') !== false || strpos($url, 'photoshop.com') !== false) {
            return '<img src="https://img.icons8.com/color/48/000000/adobe-creative-cloud.png" alt="Adobe" class="file-icon"> Adobe';
        }
        if (strpos($url, 'figma.com') !== false) {
            return '<img src="https://static.figma.com/app/icon/1/favicon.png" alt="Figma" class="file-icon"> Figma';
        }
        
        // Development Tools
        if (strpos($url, 'github.com') !== false) {
            return '<img src="https://github.githubassets.com/favicons/favicon.png" alt="GitHub" class="file-icon"> GitHub';
        }
        if (strpos($url, 'gitlab.com') !== false) {
            return '<img src="https://gitlab.com/favicon.ico" alt="GitLab" class="file-icon"> GitLab';
        }
        
        // Other Productivity Tools
        if (strpos($url, 'miro.com') !== false) {
            return '<img src="https://miro.com/favicon.ico" alt="Miro" class="file-icon"> Miro';
        }
        if (strpos($url, 'trello.com') !== false) {
            return '<img src="https://trello.com/favicon.ico" alt="Trello" class="file-icon"> Trello';
        }
        if (strpos($url, 'slack.com') !== false) {
            return '<img src="https://img.icons8.com/color/48/000000/slack-new.png" alt="Slack" class="file-icon"> Slack';
        }
        if (strpos($url, 'zoom.us') !== false) {
            return '<img src="https://img.icons8.com/color/48/000000/zoom.png" alt="Zoom" class="file-icon"> Zoom';
        }
        
        // File Type Detection for Links
        if (strpos($url, '.xls') !== false || strpos($url, '.xlsx') !== false) {
            return '<img src="https://img.icons8.com/color/48/000000/microsoft-excel-2019.png" alt="Excel File" class="file-icon"> Excel File';
        }
        
        return '<svg class="file-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.5 3H12H8a4 4 0 00-4 4v10a4 4 0 004 4h8a4 4 0 004-4V7a4 4 0 00-4-4h-1.5m-4 0v3m0 0H9m3 0h3"/></svg> Link';
    } else {
        // File Type Detection
        if (strpos($url, '.pdf') !== false) {
            return '<img src="https://img.icons8.com/color/48/000000/pdf.png" alt="PDF" class="file-icon"> PDF';
        }
        if (strpos($url, '.doc') !== false || strpos($url, '.docx') !== false) {
            return '<img src="https://img.icons8.com/color/48/000000/microsoft-word-2019.png" alt="Word Doc" class="file-icon"> Word Doc';
        }
        if (strpos($url, '.xls') !== false || strpos($url, '.xlsx') !== false) {
            return '<img src="https://img.icons8.com/color/48/000000/microsoft-excel-2019.png" alt="Excel" class="file-icon"> Excel';
        }
        if (strpos($url, '.ppt') !== false || strpos($url, '.pptx') !== false) {
            return '<img src="https://img.icons8.com/color/48/000000/microsoft-powerpoint-2019.png" alt="PowerPoint" class="file-icon"> PowerPoint';
        }
        if (strpos($url, '.psd') !== false) {
            return '<img src="https://img.icons8.com/color/48/000000/adobe-photoshop.png" alt="Photoshop" class="file-icon"> Photoshop';
        }
        if (strpos($url, '.ai') !== false) {
            return '<img src="https://img.icons8.com/color/48/000000/adobe-illustrator.png" alt="Illustrator" class="file-icon"> Illustrator';
        }
        if (strpos($url, '.fig') !== false) {
            return '<img src="https://static.figma.com/app/icon/1/favicon.png" alt="Figma" class="file-icon"> Figma';
        }
        if (strpos($url, '.png') !== false || strpos($url, '.jpg') !== false || strpos($url, '.jpeg') !== false || strpos($url, '.gif') !== false) {
            return '<img src="https://img.icons8.com/color/48/000000/image.png" alt="Image" class="file-icon"> Image';
        }
        if (strpos($url, '.zip') !== false || strpos($url, '.rar') !== false || strpos($url, '.7z') !== false) {
            return '<img src="https://img.icons8.com/color/48/000000/zip.png" alt="Archive" class="file-icon"> Archive';
        }
        if (strpos($url, '.mp4') !== false || strpos($url, '.mov') !== false || strpos($url, '.avi') !== false) {
            return '<img src="https://img.icons8.com/color/48/000000/video.png" alt="Video" class="file-icon"> Video';
        }
        
        return '<svg class="file-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z"/></svg> File';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>LinkHub - Focal</title>
    <style>
        :root {
            --bg-primary: #fefcf8;
            --bg-secondary: #ffffff;
            --bg-card: #ffffff;
            --bg-hover: #f8f6f2;
            --border-color: #e8e4df;
            --text-primary: #2d2d2d;
            --text-secondary: #6b6b6b;
            --text-muted: #9a9a9a;
            --accent-primary: #ff6314;
            --accent-secondary: #5296dd;
            --accent-hover: #ff5722;
            --success: #22c55e;
            --warning: #f59e0b;
            --pending: #94a3b8;
            --gradient: linear-gradient(135deg, #ff6314 0%, #5296dd 100%);
            --warm-orange: #ffaa7a;
            --warm-yellow: #ffeaa7;
            --warm-cream: #fff8f0;
            --shadow-soft: 0 2px 8px rgba(255, 99, 20, 0.08);
            --shadow-hover: 0 8px 24px rgba(255, 99, 20, 0.15);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Helvetica Neue', sans-serif;
            background: linear-gradient(135deg, var(--warm-cream) 0%, var(--bg-primary) 100%);
            color: var(--text-primary);
            line-height: 1.6;
            min-height: 100vh;
        }

        .container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 0 16px;
        }

        /* Header */
        .header {
            background: rgba(255, 255, 255, 0.95);
            border-bottom: 1px solid var(--border-color);
            padding: 16px 0;
            position: sticky;
            top: 0;
            z-index: 100;
            backdrop-filter: blur(20px);
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 24px;
            font-weight: 700;
            background: var(--gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            text-decoration: none;
        }

        .breadcrumb {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
            color: var(--text-secondary);
        }

        .breadcrumb a {
            color: var(--accent-secondary);
            text-decoration: none;
        }

        .breadcrumb a:hover {
            text-decoration: underline;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .user-avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: var(--gradient);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 14px;
            color: white;
        }

        /* Main Content */
        .main-content {
            padding: 32px 0;
        }

        /* Page Header */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
        }

        .page-title {
            font-size: 28px;
            font-weight: 700;
            color: var(--text-primary);
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .upload-btn {
            background: var(--gradient);
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.2s ease;
            box-shadow: 0 2px 8px rgba(255, 99, 20, 0.3);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .upload-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(255, 99, 20, 0.4);
        }

        /* Upload Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            animation: fadeIn 0.3s ease;
        }

        .modal.active {
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .modal-content {
            background: var(--bg-card);
            border-radius: 16px;
            padding: 32px;
            width: 90%;
            max-width: 500px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
            transform: scale(0.9);
            transition: transform 0.3s ease;
        }

        .modal.active .modal-content {
            transform: scale(1);
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
        }

        .modal-title {
            font-size: 20px;
            font-weight: 600;
            color: var(--text-primary);
        }

        .close-btn {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: var(--text-muted);
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: all 0.2s ease;
        }

        .close-btn:hover {
            background: var(--bg-hover);
            color: var(--text-primary);
        }

        /* Form Styles */
        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 8px;
            font-size: 14px;
        }

        .form-input,
        .form-select {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            font-size: 14px;
            background: var(--bg-secondary);
            color: var(--text-primary);
            transition: all 0.2s ease;
        }

        .form-input:focus,
        .form-select:focus {
            outline: none;
            border-color: var(--accent-primary);
            box-shadow: 0 0 0 3px rgba(255, 99, 20, 0.1);
        }

        .form-radio-group {
            display: flex;
            gap: 24px;
            margin-bottom: 20px;
            background: var(--warm-cream);
            padding: 16px;
            border-radius: 8px;
        }

        .form-radio-group label {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
            color: var(--text-primary);
            cursor: pointer;
            font-weight: 500;
        }

        .form-radio-group input[type="radio"] {
            accent-color: var(--accent-primary);
        }

        .form-button {
            background: var(--gradient);
            color: white;
            border: none;
            padding: 14px 32px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.2s ease;
            box-shadow: 0 2px 8px rgba(255, 99, 20, 0.3);
            width: 100%;
        }

        .form-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(255, 99, 20, 0.4);
        }

        /* Files Grid */
        .files-grid {
            display: grid;
            gap: 20px;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
        }

        .file-card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 20px;
            transition: all 0.2s ease;
            box-shadow: var(--shadow-soft);
            cursor: pointer;
        }

        .file-card:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-hover);
            border-color: var(--warm-orange);
        }

        .file-header {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            margin-bottom: 12px;
        }

        .file-type-badge {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 12px;
            font-weight: 600;
            background: var(--warm-cream);
            color: var(--accent-primary);
            padding: 4px 8px;
            border-radius: 6px;
            flex-shrink: 0;
        }

        .file-info {
            flex: 1;
            min-width: 0;
        }

        .file-title {
            font-size: 16px;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 4px;
            word-break: break-word;
        }

        .file-project {
            font-size: 13px;
            color: var(--accent-secondary);
            font-weight: 500;
        }

        .file-meta {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-top: 16px;
            padding-top: 16px;
            border-top: 1px solid var(--border-color);
            font-size: 12px;
            color: var(--text-muted);
        }

        .file-date {
            display: flex;
            align-items: center;
            gap: 4px;
        }

        .open-link {
            color: var(--accent-primary);
            text-decoration: none;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 4px;
            transition: color 0.2s ease;
        }

        .open-link:hover {
            color: var(--accent-hover);
        }

        .file-icon {
            width: 16px;
            height: 16px;
            vertical-align: middle;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 80px 20px;
            color: var(--text-muted);
        }

        .empty-state-icon {
            font-size: 64px;
            margin-bottom: 16px;
            opacity: 0.5;
        }

        .empty-state h3 {
            font-size: 20px;
            margin-bottom: 8px;
            color: var(--text-secondary);
        }

        .empty-state p {
            font-size: 16px;
        }

        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .file-card {
            animation: slideUp 0.4s ease forwards;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .page-header {
                flex-direction: column;
                gap: 16px;
                align-items: flex-start;
            }

            .files-grid {
                grid-template-columns: 1fr;
            }

            .modal-content {
                margin: 16px;
                padding: 24px;
            }

            .form-radio-group {
                flex-direction: column;
                gap: 12px;
            }
        }

        @media (max-width: 480px) {
            .container {
                padding: 0 12px;
            }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="header-content">
                <a href="home.php" class="logo">Focal</a>
                <div class="breadcrumb">
                    <a href="home.php">Dashboard</a>
                    <span>→</span>
                    <span>LinkHub</span>
                </div>
                <div class="user-info">
                    <div class="user-avatar"><?= strtoupper(substr($name, 0, 1)) ?></div>
                </div>
            </div>
        </div>
    </header>

    <div class="container">
        <div class="main-content">
            <div class="page-header">
                <h1 class="page-title">📂 LinkHub</h1>
                <button type="button" class="upload-btn" onclick="openModal()">
                    <span>+</span>
                    Add File or Link
                </button>
            </div>

            <?php if (count($files) > 0): ?>
                <div class="files-grid">
                    <?php foreach ($files as $index => $file): ?>
                        <div class="file-card" style="animation-delay: <?= $index * 0.1 ?>s" onclick="window.open('<?= $file['file_url'] ?>', '_blank')">
                            <div class="file-header">
                                <div class="file-type-badge">
                                    <?= getFileIcon($file) ?>
                                </div>
                                <div class="file-info">
                                    <h3 class="file-title"><?= htmlspecialchars($file['file_name']) ?></h3>
                                    <div class="file-project">📁 <?= htmlspecialchars($file['project_title']) ?></div>
                                </div>
                            </div>
                            
                            <div class="file-meta">
                                <div class="file-date">
                                    <span>🕒</span>
                                    <?= date('M j, Y', strtotime($file['uploaded_at'])) ?>
                                </div>
                                <a href="<?= $file['file_url'] ?>" target="_blank" class="open-link" onclick="event.stopPropagation()">
                                    Open
                                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6M15 3h6v6M10 14L21 3"/>
                                    </svg>
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <div class="empty-state-icon">📂</div>
                    <h3>No files yet</h3>
                    <p>Upload your first file or link to get started!</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Upload Modal -->
    <div class="modal" id="uploadModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Add File or Link</h3>
                <button type="button" class="close-btn" onclick="closeModal()">&times;</button>
            </div>
            
            <form method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label class="form-label">Project</label>
                    <select name="project_id" class="form-select" required>
                        <option value="">-- Select Project --</option>
                        <?php if (count($projects) > 0): ?>
                            <?php foreach ($projects as $project): ?>
                                <option value="<?= $project['id'] ?>"><?= htmlspecialchars($project['title']) ?></option>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <option disabled>No projects found</option>
                        <?php endif; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">Name</label>
                    <input type="text" name="file_name" class="form-input" placeholder="e.g., Q2 Budget Sheet" required>
                </div>

                <div class="form-radio-group">
                    <label>
                        <input type="radio" name="file_type" value="link" checked onclick="toggleUpload(false)">
                        📎 Link
                    </label>
                    <label>
                        <input type="radio" name="file_type" value="file" onclick="toggleUpload(true)">
                        📁 File Upload
                    </label>
                </div>

                <div class="form-group" id="linkInput">
                    <label class="form-label">URL</label>
                    <input type="url" name="file_url" class="form-input" placeholder="https://example.com">
                </div>

                <div class="form-group" id="fileInput" style="display:none;">
                    <label class="form-label">Choose File</label>
                    <input type="file" name="file_upload" class="form-input">
                </div>

                <button type="submit" class="form-button">Save</button>
            </form>
        </div>
    </div>

    <script>
        function openModal() {
            document.getElementById('uploadModal').classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        function closeModal() {
            document.getElementById('uploadModal').classList.remove('active');
            document.body.style.overflow = 'auto';
        }

        function toggleUpload(showUpload) {
            document.getElementById('linkInput').style.display = showUpload ? 'none' : 'block';
            document.getElementById('fileInput').style.display = showUpload ? 'block' : 'none';
        }

        // Close modal when clicking outside
        document.getElementById('uploadModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeModal();
            }
        });

        // Handle form submission
        document.querySelector('form').addEventListener('submit', function() {
            const button = this.querySelector('.form-button');
            button.textContent = 'Saving...';
            button.disabled = true;
        });

        // Escape key to close modal
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closeModal();
            }
        });

        // Animate file cards on load
        document.addEventListener('DOMContentLoaded', function() {
            const fileCards = document.querySelectorAll('.file-card');
            fileCards.forEach((card, index) => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                setTimeout(() => {
                    card.style.transition = 'all 0.4s ease';
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, index * 100);
            });
        });
    </script>
</body>
</html>