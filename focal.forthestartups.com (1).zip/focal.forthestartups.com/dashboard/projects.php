<?php
include '../includes/auth.php';
require_once '../config/db.php';

$user_id = $_SESSION['user_id'];
$name = $_SESSION['name'] ?? '';

// Handle project creation
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $desc = trim($_POST['description'] ?? '');

    if (!empty($title)) {
        // Insert new project
        $stmt = $pdo->prepare("INSERT INTO projects (user_id, title, description) VALUES (?, ?, ?)");
        $stmt->execute([$user_id, $title, $desc]);

        // Get the new project ID for linking
        $project_id = $pdo->lastInsertId();

        // Create notification with link
        $safeTitle = htmlspecialchars($title);
        $link = "projects.php#project-$project_id";
        addNotification(
            $pdo,
            $user_id,
            "📁 New project created: <strong>$safeTitle</strong>",
            $link
        );

        header("Location: projects.php");
        exit;
    }
}

// Get user's projects with task counts
$stmt = $pdo->prepare("
    SELECT p.*, 
           COUNT(t.id) as task_count,
           COUNT(CASE WHEN t.status = 'completed' THEN 1 END) as completed_tasks
    FROM projects p 
    LEFT JOIN tasks t ON p.id = t.project_id 
    WHERE p.user_id = ? 
    GROUP BY p.id 
    ORDER BY p.created_at DESC
");
$stmt->execute([$user_id]);
$projects = $stmt->fetchAll();
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Projects - Focal</title>
  <style>
    :root {
      --bg-primary: #fefcf8;
      --bg-secondary: #ffffff;
      --bg-card: #ffffff;
      --bg-hover: #f8f6f2;
      --border-color: #e8e4df;
      --text-primary: #2d2d2d;
      --text-secondary: #6b6b6b;
      --text-muted: #9a9a9a;
      --accent-primary: #ff6314;
      --accent-secondary: #5296dd;
      --accent-hover: #ff5722;
      --success: #22c55e;
      --warning: #f59e0b;
      --gradient: linear-gradient(135deg, #ff6314 0%, #5296dd 100%);
      --warm-orange: #ffaa7a;
      --warm-yellow: #ffeaa7;
      --warm-cream: #fff8f0;
      --shadow-soft: 0 2px 8px rgba(255, 99, 20, 0.08);
      --shadow-hover: 0 8px 24px rgba(255, 99, 20, 0.15);
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Helvetica Neue', sans-serif;
      background: linear-gradient(135deg, var(--warm-cream) 0%, var(--bg-primary) 100%);
      color: var(--text-primary);
      line-height: 1.6;
      min-height: 100vh;
    }

    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 16px;
    }

    /* Header */
    .header {
      background: rgba(255, 255, 255, 0.95);
      border-bottom: 1px solid var(--border-color);
      padding: 16px 0;
      position: sticky;
      top: 0;
      z-index: 100;
      backdrop-filter: blur(20px);
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
    }

    .header-content {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .logo {
      font-size: 24px;
      font-weight: 700;
      background: var(--gradient);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
      text-decoration: none;
    }

    .breadcrumb {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 14px;
      color: var(--text-secondary);
    }

    .breadcrumb a {
      color: var(--accent-secondary);
      text-decoration: none;
    }

    .breadcrumb a:hover {
      text-decoration: underline;
    }

    .user-info {
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .user-avatar {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      background: var(--gradient);
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 600;
      font-size: 14px;
      color: white;
    }

    /* Main Content */
    .main-content {
      display: grid;
      grid-template-columns: 400px 1fr;
      gap: 24px;
      padding: 24px 0;
    }

    .sidebar {
      position: sticky;
      top: 88px;
      height: fit-content;
    }

    .content {
      display: flex;
      flex-direction: column;
      gap: 20px;
    }

    /* Cards */
    .card {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: 12px;
      overflow: hidden;
      transition: all 0.3s ease;
      box-shadow: var(--shadow-soft);
    }

    .card:hover {
      border-color: var(--warm-orange);
      box-shadow: var(--shadow-hover);
      transform: translateY(-1px);
    }

    .card-header {
      padding: 20px 24px;
      border-bottom: 1px solid var(--border-color);
      background: var(--warm-cream);
    }

    .card-title {
      font-size: 20px;
      font-weight: 600;
      color: var(--text-primary);
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .card-content {
      padding: 24px;
    }

    /* Form Styles */
    .form-group {
      margin-bottom: 20px;
    }

    .form-label {
      display: block;
      font-weight: 600;
      color: var(--text-primary);
      margin-bottom: 8px;
      font-size: 14px;
    }

    .form-input,
    .form-textarea {
      width: 100%;
      padding: 12px 16px;
      border: 2px solid var(--border-color);
      border-radius: 8px;
      font-size: 14px;
      background: var(--bg-secondary);
      color: var(--text-primary);
      transition: all 0.2s ease;
      font-family: inherit;
    }

    .form-textarea {
      min-height: 100px;
      resize: vertical;
    }

    .form-input:focus,
    .form-textarea:focus {
      outline: none;
      border-color: var(--accent-primary);
      box-shadow: 0 0 0 3px rgba(255, 99, 20, 0.1);
    }

    .form-button {
      background: var(--gradient);
      color: white;
      border: none;
      padding: 14px 24px;
      border-radius: 8px;
      font-weight: 600;
      font-size: 14px;
      cursor: pointer;
      transition: all 0.2s ease;
      box-shadow: 0 2px 8px rgba(255, 99, 20, 0.3);
      width: 100%;
    }

    .form-button:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(255, 99, 20, 0.4);
    }

    .form-button:disabled {
      opacity: 0.6;
      cursor: not-allowed;
      transform: none;
    }

    /* Project Grid */
    .projects-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
      gap: 20px;
    }

    .project-card {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: 12px;
      padding: 24px;
      transition: all 0.3s ease;
      box-shadow: var(--shadow-soft);
      position: relative;
      cursor: pointer;
    }

    .project-card:hover {
      transform: translateY(-4px);
      box-shadow: var(--shadow-hover);
      border-color: var(--warm-orange);
    }

    .project-card::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 4px;
      background: var(--gradient);
      border-radius: 12px 12px 0 0;
    }

    .project-header {
      display: flex;
      align-items: flex-start;
      justify-content: space-between;
      margin-bottom: 16px;
    }

    .project-icon {
      font-size: 24px;
      padding: 12px;
      background: var(--warm-cream);
      border-radius: 10px;
      margin-right: 12px;
    }

    .project-title {
      font-size: 20px;
      font-weight: 700;
      color: var(--text-primary);
      margin-bottom: 8px;
      line-height: 1.3;
    }

    .project-description {
      color: var(--text-secondary);
      font-size: 14px;
      line-height: 1.5;
      margin-bottom: 20px;
      display: -webkit-box;
      -webkit-line-clamp: 3;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }

    .project-stats {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding-top: 16px;
      border-top: 1px solid var(--border-color);
    }

    .project-meta {
      display: flex;
      gap: 16px;
      font-size: 13px;
      color: var(--text-muted);
    }

    .project-meta-item {
      display: flex;
      align-items: center;
      gap: 4px;
    }

    .project-progress {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13px;
      color: var(--text-secondary);
    }

    .progress-bar {
      width: 80px;
      height: 6px;
      background: var(--border-color);
      border-radius: 3px;
      overflow: hidden;
    }

    .progress-fill {
      height: 100%;
      background: var(--gradient);
      border-radius: 3px;
      transition: width 0.3s ease;
    }

    /* Empty State */
    .empty-state {
      text-align: center;
      padding: 80px 20px;
      color: var(--text-muted);
    }

    .empty-state-icon {
      font-size: 80px;
      margin-bottom: 20px;
      opacity: 0.5;
    }

    .empty-state h3 {
      font-size: 24px;
      margin-bottom: 12px;
      color: var(--text-secondary);
    }

    .empty-state p {
      font-size: 16px;
      margin-bottom: 24px;
    }

    .empty-state-cta {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 12px 24px;
      background: var(--gradient);
      color: white;
      text-decoration: none;
      border-radius: 8px;
      font-weight: 600;
      transition: all 0.2s ease;
    }

    .empty-state-cta:hover {
      transform: translateY(-2px);
      box-shadow: var(--shadow-hover);
    }

    /* Stats Widget */
    .stats-overview {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 16px;
      margin-bottom: 24px;
    }

    .stat-item {
      background: var(--warm-cream);
      padding: 20px;
      border-radius: 10px;
      text-align: center;
      border: 1px solid var(--border-color);
    }

    .stat-number {
      font-size: 28px;
      font-weight: 700;
      background: var(--gradient);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
      margin-bottom: 4px;
    }

    .stat-label {
      font-size: 12px;
      color: var(--text-secondary);
      text-transform: uppercase;
      font-weight: 600;
      letter-spacing: 0.5px;
    }

    /* Responsive */
    @media (max-width: 768px) {
      .main-content {
        grid-template-columns: 1fr;
      }
      
      .sidebar {
        position: static;
        order: 2;
      }
      
      .content {
        order: 1;
      }

      .projects-grid {
        grid-template-columns: 1fr;
      }

      .stats-overview {
        grid-template-columns: 1fr;
      }
    }

    @media (max-width: 480px) {
      .container {
        padding: 0 12px;
      }
      
      .project-card {
        padding: 20px;
      }
    }

    /* Loading Animation */
    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(30px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .project-card {
      animation: fadeInUp 0.5s ease forwards;
    }
  </style>
</head>
<body>
  <header class="header">
    <div class="container">
      <div class="header-content">
        <a href="home.php" class="logo">Focal</a>
        <div class="breadcrumb">
          <a href="home.php">Dashboard</a>
          <span>→</span>
          <span>Projects</span>
        </div>
        <div class="user-info">
          <div class="user-avatar"><?= strtoupper(substr($name, 0, 1)) ?></div>
        </div>
      </div>
    </div>
  </header>

  <div class="container">
    <div class="main-content">
      <aside class="sidebar">
        <!-- Create Project Form -->
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">📁 Create New Project</h3>
          </div>
          <div class="card-content">
            <form method="POST" id="projectForm">
              <div class="form-group">
                <label class="form-label">Project Title</label>
                <input type="text" name="title" class="form-input" placeholder="Enter project name..." required>
              </div>

              <div class="form-group">
                <label class="form-label">Description</label>
                <textarea name="description" class="form-textarea" placeholder="Describe your project goals and objectives..."></textarea>
              </div>

              <button type="submit" class="form-button" id="submitBtn">Create Project</button>
            </form>
          </div>
        </div>

        <!-- Project Stats -->
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">📊 Project Overview</h3>
          </div>
          <div class="card-content">
            <div class="stats-overview">
              <?php
              $total_projects = count($projects);
              $total_tasks = array_sum(array_column($projects, 'task_count'));
              $completed_tasks = array_sum(array_column($projects, 'completed_tasks'));
              $active_projects = count(array_filter($projects, fn($p) => $p['task_count'] > $p['completed_tasks']));
              ?>
              <div class="stat-item">
                <div class="stat-number"><?= $total_projects ?></div>
                <div class="stat-label">Total Projects</div>
              </div>
              <div class="stat-item">
                <div class="stat-number"><?= $active_projects ?></div>
                <div class="stat-label">Active Projects</div>
              </div>
              <div class="stat-item">
                <div class="stat-number"><?= $total_tasks ?></div>
                <div class="stat-label">Total Tasks</div>
              </div>
              <div class="stat-item">
                <div class="stat-number"><?= $completed_tasks ?></div>
                <div class="stat-label">Completed</div>
              </div>
            </div>
          </div>
        </div>
      </aside>

      <main class="content">
        <!-- Page Header -->
        <div class="card">
          <div class="card-header">
            <h2 class="card-title">📁 Your Projects (<?= count($projects) ?>)</h2>
          </div>
        </div>

        <!-- Projects Grid -->
        <?php if (count($projects) > 0): ?>
          <div class="projects-grid">
            <?php foreach ($projects as $project): ?>
              <?php
              $progress = $project['task_count'] > 0 ? 
                round(($project['completed_tasks'] / $project['task_count']) * 100) : 0;
              ?>
              <div class="project-card" onclick="window.location.href='project_detail.php?id=<?= $project['id'] ?>'">
                <div class="project-header">
                  <div style="flex: 1;">
                    <h3 class="project-title"><?= htmlspecialchars($project['title']) ?></h3>
                    <?php if (!empty($project['description'])): ?>
                      <p class="project-description"><?= htmlspecialchars($project['description']) ?></p>
                    <?php else: ?>
                      <p class="project-description" style="font-style: italic; color: var(--text-muted);">No description provided</p>
                    <?php endif; ?>
                  </div>
                  <div class="project-icon">📁</div>
                </div>

                <div class="project-stats">
                  <div class="project-meta">
                    <div class="project-meta-item">
                      <span>📅</span>
                      <span><?= date('M j, Y', strtotime($project['created_at'])) ?></span>
                    </div>
                    <div class="project-meta-item">
                      <span>📝</span>
                      <span><?= $project['task_count'] ?> tasks</span>
                    </div>
                  </div>
                  
                  <div class="project-progress">
                    <div class="progress-bar">
                      <div class="progress-fill" style="width: <?= $progress ?>%"></div>
                    </div>
                    <span><?= $progress ?>%</span>
                  </div>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php else: ?>
          <div class="card">
            <div class="card-content">
              <div class="empty-state">
                <div class="empty-state-icon">📁</div>
                <h3>No projects yet</h3>
                <p>Create your first project to start organizing your work and tracking progress!</p>
                <a href="#projectForm" class="empty-state-cta" onclick="document.querySelector('#projectForm input').focus()">
                  <span>➕</span>
                  <span>Create Your First Project</span>
                </a>
              </div>
            </div>
          </div>
        <?php endif; ?>
      </main>
    </div>
  </div>

  <script>
    // Form submission handling
    document.getElementById('projectForm').addEventListener('submit', function() {
      const button = document.getElementById('submitBtn');
      button.textContent = 'Creating...';
      button.disabled = true;
    });

    // Animate project cards on load
    document.addEventListener('DOMContentLoaded', function() {
      const projectCards = document.querySelectorAll('.project-card');
      projectCards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(30px)';
        setTimeout(() => {
          card.style.transition = 'all 0.5s ease';
          card.style.opacity = '1';
          card.style.transform = 'translateY(0)';
        }, index * 100);
      });

      // Focus on title input when empty state CTA is clicked
      const emptyCTA = document.querySelector('.empty-state-cta');
      if (emptyCTA) {
        emptyCTA.addEventListener('click', function(e) {
          e.preventDefault();
          document.querySelector('#projectForm input[name="title"]').focus();
          document.querySelector('.sidebar').scrollIntoView({ behavior: 'smooth' });
        });
      }
    });

    // Add hover effect sound (optional)
    document.querySelectorAll('.project-card').forEach(card => {
      card.addEventListener('mouseenter', function() {
        this.style.transform = 'translateY(-6px)';
      });
      
      card.addEventListener('mouseleave', function() {
        this.style.transform = 'translateY(-4px)';
      });
    });

    // Auto-resize textarea
    const textarea = document.querySelector('.form-textarea');
    if (textarea) {
      textarea.addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = Math.max(100, this.scrollHeight) + 'px';
      });
    }
  </script>
</body>
</html>