<?php
include '../includes/auth.php';
require_once '../config/db.php';

// Ensure UTF-8 encoding for the database connection
$pdo->exec("SET NAMES 'utf8mb4' COLLATE 'utf8mb4_unicode_ci'");

$user_id = $_SESSION['user_id'];
$name = $_SESSION['name'] ?? '';

// Function to safely render notification messages with <strong> tags
function renderSafeMessage($message) {
    // Allow only <strong> tags, strip others, and ensure UTF-8 encoding
    return strip_tags($message, '<strong>');
}

// Helper: detect file/link type icon
function getFileIcon($file) {
    $url = strtolower($file['file_url']);
    if ($file['file_type'] === 'link') {
        // Productivity & Collaboration Tools
        if (strpos($url, 'notion.so') !== false) {
            return '<img src="https://www.notion.so/images/favicon.ico" alt="Notion" class="file-icon"> Notion';
        }
        if (strpos($url, 'docs.google.com') !== false) {
            return '<img src="https://img.icons8.com/color/48/000000/google-docs.png" alt="Google Doc" class="file-icon"> Google Doc';
        }
        if (strpos($url, 'sheets.google.com') !== false) {
            return '<img src="https://img.icons8.com/color/48/000000/google-sheets.png" alt="Google Sheet" class="file-icon"> Google Sheet';
        }
        if (strpos($url, 'slides.google.com') !== false) {
            return '<img src="https://img.icons8.com/color/48/000000/google-slides.png" alt="Google Slides" class="file-icon"> Google Slides';
        }
        if (strpos($url, 'drive.google.com') !== false) {
            return '<img src="https://img.icons8.com/color/48/000000/google-drive.png" alt="Google Drive" class="file-icon"> Google Drive';
        }
        
        // Design & Creative Tools
        if (strpos($url, 'canva.com') !== false) {
            return '<img src="https://static.canva.com/static/images/favicon.ico" alt="Canva" class="file-icon"> Canva';
        }
        if (strpos($url, 'adobe.com') !== false || strpos($url, 'photoshop.com') !== false) {
            return '<img src="https://img.icons8.com/color/48/000000/adobe-creative-cloud.png" alt="Adobe" class="file-icon"> Adobe';
        }
        if (strpos($url, 'figma.com') !== false) {
            return '<img src="https://static.figma.com/app/icon/1/favicon.png" alt="Figma" class="file-icon"> Figma';
        }
        
        // Development Tools
        if (strpos($url, 'github.com') !== false) {
            return '<img src="https://github.githubassets.com/favicons/favicon.png" alt="GitHub" class="file-icon"> GitHub';
        }
        if (strpos($url, 'gitlab.com') !== false) {
            return '<img src="https://gitlab.com/favicon.ico" alt="GitLab" class="file-icon"> GitLab';
        }
        
        // Other Productivity Tools
        if (strpos($url, 'miro.com') !== false) {
            return '<img src="https://miro.com/favicon.ico" alt="Miro" class="file-icon"> Miro';
        }
        if (strpos($url, 'trello.com') !== false) {
            return '<img src="https://trello.com/favicon.ico" alt="Trello" class="file-icon"> Trello';
        }
        if (strpos($url, 'slack.com') !== false) {
            return '<img src="https://img.icons8.com/color/48/000000/slack-new.png" alt="Slack" class="file-icon"> Slack';
        }
        if (strpos($url, 'zoom.us') !== false) {
            return '<img src="https://img.icons8.com/color/48/000000/zoom.png" alt="Zoom" class="file-icon"> Zoom';
        }
        
        // File Type Detection for Links
        if (strpos($url, '.xls') !== false || strpos($url, '.xlsx') !== false) {
            return '<img src="https://img.icons8.com/color/48/000000/microsoft-excel-2019.png" alt="Excel File" class="file-icon"> Excel File';
        }
        
        return '<svg class="file-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.5 3H12H8a4 4 0 00-4 4v10a4 4 0 004 4h8a4 4 0 004-4V7a4 4 0 00-4-4h-1.5m-4 0v3m0 0H9m3 0h3"/></svg> Link';
    } else {
        // File Type Detection
        if (strpos($url, '.pdf') !== false) {
            return '<img src="https://img.icons8.com/color/48/000000/pdf.png" alt="PDF" class="file-icon"> PDF';
        }
        if (strpos($url, '.doc') !== false || strpos($url, '.docx') !== false) {
            return '<img src="https://img.icons8.com/color/48/000000/microsoft-word-2019.png" alt="Word Doc" class="file-icon"> Word Doc';
        }
        if (strpos($url, '.xls') !== false || strpos($url, '.xlsx') !== false) {
            return '<img src="https://img.icons8.com/color/48/000000/microsoft-excel-2019.png" alt="Excel" class="file-icon"> Excel';
        }
        if (strpos($url, '.ppt') !== false || strpos($url, '.pptx') !== false) {
            return '<img src="https://img.icons8.com/color/48/000000/microsoft-powerpoint-2019.png" alt="PowerPoint" class="file-icon"> PowerPoint';
        }
        if (strpos($url, '.psd') !== false) {
            return '<img src="https://img.icons8.com/color/48/000000/adobe-photoshop.png" alt="Photoshop" class="file-icon"> Photoshop';
        }
        if (strpos($url, '.ai') !== false) {
            return '<img src="https://img.icons8.com/color/48/000000/adobe-illustrator.png" alt="Illustrator" class="file-icon"> Illustrator';
        }
        if (strpos($url, '.fig') !== false) {
            return '<img src="https://static.figma.com/app/icon/1/favicon.png" alt="Figma" class="file-icon"> Figma';
        }
        if (strpos($url, '.png') !== false || strpos($url, '.jpg') !== false || strpos($url, '.jpeg') !== false || strpos($url, '.gif') !== false) {
            return '<img src="https://img.icons8.com/color/48/000000/image.png" alt="Image" class="file-icon"> Image';
        }
        if (strpos($url, '.zip') !== false || strpos($url, '.rar') !== false || strpos($url, '.7z') !== false) {
            return '<img src="https://img.icons8.com/color/48/000000/zip.png" alt="Archive" class="file-icon"> Archive';
        }
        if (strpos($url, '.mp4') !== false || strpos($url, '.mov') !== false || strpos($url, '.avi') !== false) {
            return '<img src="https://img.icons8.com/color/48/000000/video.png" alt="Video" class="file-icon"> Video';
        }
        
        return '<svg class="file-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z"/></svg> File';
    }
}

// Count metrics
$project_count = $pdo->query("SELECT COUNT(*) FROM projects WHERE user_id = $user_id")->fetchColumn();
$task_count = $pdo->query("SELECT COUNT(*) FROM tasks WHERE project_id IN (SELECT id FROM projects WHERE user_id = $user_id)")->fetchColumn();
$file_count = $pdo->query("SELECT COUNT(*) FROM project_files WHERE uploaded_by = $user_id")->fetchColumn();
$unread_notifications = $pdo->query("SELECT COUNT(*) FROM notifications WHERE user_id = $user_id AND is_read = 0")->fetchColumn();

// Fetch recent files
$recent_files_stmt = $pdo->prepare("
    SELECT pf.*, p.title AS project_title 
    FROM project_files pf 
    JOIN projects p ON pf.project_id = p.id 
    WHERE p.user_id = ? 
    ORDER BY pf.uploaded_at DESC 
    LIMIT 3
");
$recent_files_stmt->execute([$user_id]);
$recent_files = $recent_files_stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Focal Dashboard</title>
  <style>
    :root {
      --bg-primary: #fefcf8;
      --bg-secondary: #ffffff;
      --bg-card: #ffffff;
      --bg-hover: #f8f6f2;
      --border-color: #e8e4df;
      --text-primary: #2d2d2d;
      --text-secondary: #6b6b6b;
      --text-muted: #9a9a9a;
      --accent-primary: #ff6314;
      --accent-secondary: #5296dd;
      --accent-hover: #ff5722;
      --success: #22c55e;
      --warning: #f59e0b;
      --gradient: linear-gradient(135deg, #ff6314 0%, #5296dd 100%);
      --warm-orange: #ffaa7a;
      --warm-yellow: #ffeaa7;
      --warm-cream: #fff8f0;
      --shadow-soft: 0 2px 8px rgba(255, 99, 20, 0.08);
      --shadow-hover: 0 8px 24px rgba(255, 99, 20, 0.15);
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Helvetica Neue', sans-serif;
      background: linear-gradient(135deg, var(--warm-cream) 0%, var(--bg-primary) 100%);
      color: var(--text-primary);
      line-height: 1.6;
      min-height: 100vh;
    }

    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 16px;
    }

    /* Header */
    .header {
      background: rgba(255, 255, 255, 0.95);
      border-bottom: 1px solid var(--border-color);
      padding: 16px 0;
      position: sticky;
      top: 0;
      z-index: 100;
      backdrop-filter: blur(20px);
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
    }

    .header-content {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .logo {
      font-size: 24px;
      font-weight: 700;
      background: var(--gradient);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }

    .user-info {
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .user-avatar {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      background: var(--gradient);
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 600;
      font-size: 14px;
      color: white;
    }

    .welcome-text {
      font-size: 14px;
      color: var(--text-secondary);
    }

    /* Main Content */
    .main-content {
      display: grid;
      grid-template-columns: 1fr 320px;
      gap: 24px;
      padding: 24px 0;
    }

    .feed {
      display: flex;
      flex-direction: column;
      gap: 24px;
    }

    .sidebar {
      position: sticky;
      top: 88px;
      height: fit-content;
    }

    /* Cards */
    .card {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: 12px;
      overflow: hidden;
      transition: all 0.2s ease;
      box-shadow: var(--shadow-soft);
    }

    .card:hover {
      border-color: var(--warm-orange);
      box-shadow: var(--shadow-hover);
      transform: translateY(-1px);
    }

    .card-header {
      padding: 20px 24px;
      border-bottom: 1px solid var(--border-color);
      display: flex;
      align-items: center;
      justify-content: space-between;
      background: var(--warm-cream);
    }

    .card-title {
      font-size: 18px;
      font-weight: 600;
      color: var(--text-primary);
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .card-content {
      padding: 24px;
    }

    /* Recent Files */
    .recent-files-grid {
      display: grid;
      gap: 16px;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    }

    .recent-file-card {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: 8px;
      padding: 16px;
      transition: all 0.2s ease;
      cursor: pointer;
      position: relative;
    }

    .recent-file-card:hover {
      transform: translateY(-2px);
      box-shadow: var(--shadow-hover);
      border-color: var(--warm-orange);
    }

    .recent-file-card::before {
      content: '';
      position: absolute;
      left: 0;
      top: 0;
      bottom: 0;
      width: 3px;
      border-radius: 8px 0 0 8px;
      background: var(--accent-primary);
    }

    .file-header {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      margin-bottom: 12px;
    }

    .file-type-badge {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 11px;
      font-weight: 600;
      background: var(--warm-cream);
      color: var(--accent-primary);
      padding: 4px 8px;
      border-radius: 6px;
      flex-shrink: 0;
    }

    .file-info {
      flex: 1;
      min-width: 0;
    }

    .file-title {
      font-size: 14px;
      font-weight: 600;
      color: var(--text-primary);
      margin-bottom: 4px;
      word-break: break-word;
      line-height: 1.3;
    }

    .file-project {
      font-size: 12px;
      color: var(--accent-secondary);
      font-weight: 500;
    }

    .file-meta {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-top: 12px;
      padding-top: 12px;
      border-top: 1px solid var(--border-color);
      font-size: 11px;
      color: var(--text-muted);
    }

    .file-date {
      display: flex;
      align-items: center;
      gap: 4px;
    }

    .open-link {
      color: var(--accent-primary);
      text-decoration: none;
      font-weight: 600;
      display: flex;
      align-items: center;
      gap: 4px;
      transition: color 0.2s ease;
    }

    .open-link:hover {
      color: var(--accent-hover);
    }

    .file-icon {
      width: 14px;
      height: 14px;
      vertical-align: middle;
    }

    /* Stats Cards */
    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 16px;
    }

    .stat-card {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: 12px;
      padding: 24px 20px;
      text-align: center;
      transition: all 0.3s ease;
      cursor: pointer;
      text-decoration: none;
      color: inherit;
      position: relative;
      overflow: hidden;
      box-shadow: var(--shadow-soft);
    }

    .stat-card:hover {
      background: var(--warm-cream);
      transform: translateY(-4px);
      box-shadow: var(--shadow-hover);
      border-color: var(--warm-orange);
    }

    .stat-card::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 4px;
      background: var(--gradient);
      transform: scaleX(0);
      transition: transform 0.3s ease;
      border-radius: 12px 12px 0 0;
    }

    .stat-card:hover::before {
      transform: scaleX(1);
    }

    .stat-icon {
      font-size: 28px;
      margin-bottom: 12px;
      display: block;
      filter: drop-shadow(0 2px 4px rgba(255, 99, 20, 0.2));
    }

    .stat-number {
      font-size: 32px;
      font-weight: 700;
      color: var(--text-primary);
      margin-bottom: 6px;
      background: var(--gradient);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }

    .stat-label {
      font-size: 14px;
      color: var(--text-secondary);
      font-weight: 500;
    }

    /* Notifications */
    .notification-item {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      padding: 12px 0;
      border-bottom: 1px solid var(--border-color);
    }

    .notification-item:last-child {
      border-bottom: none;
    }

    .notification-dot {
      width: 10px;
      height: 10px;
      border-radius: 50%;
      background: linear-gradient(135deg, var(--accent-primary), var(--warm-orange));
      margin-top: 6px;
      flex-shrink: 0;
      box-shadow: 0 2px 4px rgba(255, 99, 20, 0.3);
    }

    .notification-content {
      flex: 1;
    }

    .notification-message {
      font-size: 14px;
      color: var(--text-primary);
      margin-bottom: 4px;
    }

    .notification-message a {
      color: var(--accent-secondary);
      text-decoration: none;
    }

    .notification-message a:hover {
      text-decoration: underline;
    }

    .notification-time {
      font-size: 12px;
      color: var(--text-muted);
    }

    .more-button {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 10px 16px;
      background: var(--gradient);
      border: none;
      color: white;
      text-decoration: none;
      border-radius: 8px;
      font-weight: 600;
      font-size: 14px;
      transition: all 0.2s ease;
      margin-top: 16px;
      box-shadow: 0 2px 8px rgba(255, 99, 20, 0.3);
    }

    .more-button:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(255, 99, 20, 0.4);
    }

    /* Sidebar Widget */
    .widget {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: 12px;
      overflow: hidden;
      margin-bottom: 16px;
      box-shadow: var(--shadow-soft);
    }

    .widget-header {
      padding: 16px;
      border-bottom: 1px solid var(--border-color);
      font-weight: 600;
      font-size: 14px;
      color: var(--text-primary);
      background: var(--warm-cream);
    }

    .widget-content {
      padding: 16px;
    }

    .quick-actions {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    .quick-action {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 14px 16px;
      border-radius: 8px;
      background: var(--warm-cream);
      border: 1px solid var(--border-color);
      text-decoration: none;
      color: var(--text-primary);
      font-size: 14px;
      font-weight: 500;
      transition: all 0.2s ease;
    }

    .quick-action:hover {
      background: var(--warm-yellow);
      border-color: var(--warm-orange);
      transform: translateX(4px);
    }

    .logout-btn {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 12px 20px;
      background: linear-gradient(135deg, var(--accent-primary), var(--accent-hover));
      border: none;
      color: white;
      text-decoration: none;
      border-radius: 8px;
      font-weight: 600;
      font-size: 14px;
      transition: all 0.2s ease;
      margin-top: 16px;
      box-shadow: 0 2px 8px rgba(255, 99, 20, 0.3);
    }

    .logout-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(255, 99, 20, 0.4);
    }

    .overview-link {
      color: inherit;
      text-decoration: none;
      transition: color 0.2s ease;
    }

    .overview-link:hover {
      color: var(--accent-secondary);
      text-decoration: underline;
    }

    .overview-row {
      display: flex;
      justify-content: space-between;
      margin-bottom: 8px;
      padding: 4px 8px;
      border-radius: 4px;
      transition: background 0.2s ease;
    }

    .overview-row:hover {
      background: var(--bg-hover);
    }

    /* Empty State */
    .empty-state {
      text-align: center;
      padding: 40px 20px;
      color: var(--text-muted);
    }

    .empty-state-icon {
      font-size: 48px;
      margin-bottom: 16px;
      opacity: 0.5;
    }

    /* View All Link */
    .view-all-link {
      color: var(--accent-secondary);
      text-decoration: none;
      font-size: 14px;
      font-weight: 500;
      transition: color 0.2s ease;
    }

    .view-all-link:hover {
      color: var(--accent-primary);
      text-decoration: underline;
    }

    /* Responsive */
    @media (max-width: 768px) {
      .main-content {
        grid-template-columns: 1fr;
      }
      
      .sidebar {
        position: static;
      }

      .stats-grid {
        grid-template-columns: repeat(2, 1fr);
      }

      .recent-files-grid {
        grid-template-columns: 1fr;
      }

      .header-content {
        flex-direction: column;
        gap: 12px;
        text-align: center;
      }
    }

    @media (max-width: 480px) {
      .stats-grid {
        grid-template-columns: 1fr;
      }
      
      .container {
        padding: 0 12px;
      }
    }

    /* Scrollbar */
    ::-webkit-scrollbar {
      width: 8px;
    }

    ::-webkit-scrollbar-track {
      background: var(--warm-cream);
    }

    ::-webkit-scrollbar-thumb {
      background: var(--warm-orange);
      border-radius: 4px;
    }

    ::-webkit-scrollbar-thumb:hover {
      background: var(--accent-primary);
    }
  </style>
</head>
<body>
  <header class="header">
    <div class="container">
      <div class="header-content">
        <div class="logo">Focal</div>
        <div class="user-info">
          <div class="user-avatar"><?= strtoupper(substr($name, 0, 1)) ?></div>
          <div class="welcome-text">Welcome back, <strong><?= htmlspecialchars($name, ENT_QUOTES, 'UTF-8') ?></strong></div>
        </div>
      </div>
    </div>
  </header>

  <div class="container">
    <div class="main-content">
      <main class="feed">
        <!-- Recent Files -->
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">📂 Recent Files</h3>
            <a href="files.php" class="view-all-link">View All</a>
          </div>
          <div class="card-content">
            <?php if (count($recent_files) > 0): ?>
              <div class="recent-files-grid">
                <?php foreach ($recent_files as $file): ?>
                  <div class="recent-file-card" onclick="window.open('<?= $file['file_url'] ?>', '_blank')">
                    <div class="file-header">
                      <div class="file-type-badge">
                        <?= getFileIcon($file) ?>
                      </div>
                      <div class="file-info">
                        <h4 class="file-title"><?= htmlspecialchars($file['file_name']) ?></h4>
                        <div class="file-project">📁 <?= htmlspecialchars($file['project_title']) ?></div>
                      </div>
                    </div>
                    
                    <div class="file-meta">
                      <div class="file-date">
                        <span>🕒</span>
                        <?= date('M j, Y', strtotime($file['uploaded_at'])) ?>
                      </div>
                      <a href="<?= $file['file_url'] ?>" target="_blank" class="open-link" onclick="event.stopPropagation()">
                        Open
                        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                          <path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6M15 3h6v6M10 14L21 3"/>
                        </svg>
                      </a>
                    </div>
                  </div>
                <?php endforeach; ?>
              </div>
            <?php else: ?>
              <div class="empty-state">
                <div class="empty-state-icon">📁</div>
                <p>No files uploaded yet</p>
              </div>
            <?php endif; ?>
          </div>
        </div>

        <!-- Stats Overview -->
        <div class="stats-grid">
          <a class="stat-card" href="projects.php">
            <span class="stat-icon">📁</span>
            <div class="stat-number"><?= $project_count ?></div>
            <div class="stat-label">Projects</div>
          </a>
          <a class="stat-card" href="tasks.php">
            <span class="stat-icon">✅</span>
            <div class="stat-number"><?= $task_count ?></div>
            <div class="stat-label">Tasks</div>
          </a>
          <a class="stat-card" href="files.php">
            <span class="stat-icon">🗂️</span>
            <div class="stat-number"><?= $file_count ?></div>
            <div class="stat-label">Files</div>
          </a>
          <a class="stat-card" href="https://focal.forthestartups.com/notifications/index.php">
            <span class="stat-icon">🔔</span>
            <div class="stat-number"><?= $unread_notifications ?></div>
            <div class="stat-label">Notifications</div>
          </a>
        </div>

        <!-- Recent Activity -->
        <div class="card" id="notifications">
          <div class="card-header">
            <h3 class="card-title">🔔 Recent Activity</h3>
          </div>
          <div class="card-content">
            <?php
            $stmt = $pdo->prepare("SELECT message, link, created_at FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 3");
            $stmt->execute([$user_id]);
            $notifications = $stmt->fetchAll();

            if (count($notifications) > 0) {
                foreach ($notifications as $note) {
                    echo '<div class="notification-item">';
                    echo '<div class="notification-dot"></div>';
                    echo '<div class="notification-content">';
                    echo '<div class="notification-message">';
                    if (!empty($note['link'])) {
                        echo "<a href='" . htmlspecialchars($note['link'], ENT_QUOTES, 'UTF-8') . "'>" . renderSafeMessage($note['message']) . "</a>";
                    } else {
                        echo renderSafeMessage($note['message']);
                    }
                    echo '</div>';
                    echo '<div class="notification-time">' . date('M j, Y \a\t g:i A', strtotime($note['created_at'])) . '</div>';
                    echo '</div>';
                    echo '</div>';
                }
                echo '<a href="https://focal.forthestartups.com/notifications/index.php" class="more-button">View All Notifications</a>';
            } else {
                echo '<div class="empty-state">';
                echo '<div class="empty-state-icon">📭</div>';
                echo '<p>No recent activity to show</p>';
                echo '</div>';
            }
            ?>
          </div>
        </div>
      </main>

      <aside class="sidebar">
        <!-- Quick Actions -->
        <div class="widget">
          <div class="widget-header">Quick Actions</div>
          <div class="widget-content">
            <div class="quick-actions">
              <a href="projects.php?action=new" class="quick-action">
                <span>➕</span>
                <span>New Project</span>
              </a>
              <a href="tasks.php?action=new" class="quick-action">
                <span>📝</span>
                <span>Add Task</span>
              </a>
              <a href="files.php?action=upload" class="quick-action">
                <span>📤</span>
                <span>Upload File</span>
              </a>
              <a href="settings.php" class="quick-action">
                <span>⚙️</span>
                <span>Settings</span>
              </a>
            </div>
            <a class="logout-btn" href="../logout.php">
              <span>🚪</span>
              <span>Logout</span>
            </a>
          </div>
        </div>

        <!-- Stats Widget -->
        <div class="widget">
          <div class="widget-header">Overview</div>
          <div class="widget-content">
            <div style="font-size: 14px; color: var(--text-secondary); line-height: 1.8;">
              <a href="https://focal.forthestartups.com/dashboard/projects.php" class="overview-link">
                <div class="overview-row">
                  <span>Total Projects:</span>
                  <strong style="color: var(--text-primary);"><?= $project_count ?></strong>
                </div>
              </a>
              <a href="https://focal.forthestartups.com/dashboard/tasks.php" class="overview-link">
                <div class="overview-row">
                  <span>Active Tasks:</span>
                  <strong style="color: var(--success);"><?= $task_count ?></strong>
                </div>
              </a>
              <a href="https://focal.forthestartups.com/dashboard/files.php" class="overview-link">
                <div class="overview-row">
                  <span>Files Stored:</span>
                  <strong style="color: var(--accent-secondary);"><?= $file_count ?></strong>
                </div>
              </a>
              <a href="https://focal.forthestartups.com/notifications/index.php" class="overview-link">
                <div class="overview-row">
                  <span>Unread:</span>
                  <strong style="color: var(--accent-primary);"><?= $unread_notifications ?></strong>
                </div>
              </a>
            </div>
          </div>
        </div>
      </aside>
    </div>
  </div>

  <script>
    // Add some subtle interactivity
    document.addEventListener('DOMContentLoaded', function() {
      // Animate recent files on load
      const recentFileCards = document.querySelectorAll('.recent-file-card');
      recentFileCards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        setTimeout(() => {
          card.style.transition = 'all 0.4s ease';
          card.style.opacity = '1';
          card.style.transform = 'translateY(0)';
        }, index * 100);
      });

      // Animate stat cards on load
      const statCards = document.querySelectorAll('.stat-card');
      statCards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        setTimeout(() => {
          card.style.transition = 'all 0.4s ease';
          card.style.opacity = '1';
          card.style.transform = 'translateY(0)';
        }, (index + 3) * 100); // Delay after recent files
      });

      // Mark notifications as read when clicked
      const notificationLinks = document.querySelectorAll('.notification-message a');
      notificationLinks.forEach(link => {
        link.addEventListener('click', function() {
          this.style.opacity = '0.7';
        });
      });

      // Animate overview rows on hover
      const overviewRows = document.querySelectorAll('.overview-row');
      overviewRows.forEach(row => {
        row.addEventListener('mouseenter', function() {
          this.style.transition = 'background 0.2s ease';
          this.style.background = 'var(--bg-hover)';
        });
        row.addEventListener('mouseleave', function() {
          this.style.background = 'transparent';
        });
      });
    });
  </script>
</body>
</html>