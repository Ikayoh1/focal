<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include '../includes/auth.php';
require_once '../config/db.php';

$user_id = $_SESSION['user_id'];
$name = $_SESSION['name'] ?? '';

// Handle task creation
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $project_id = $_POST['project_id'] ?? null;
    $title = trim($_POST['title'] ?? '');
    $due_date = $_POST['due_date'] ?? null;

    if (!empty($title) && !empty($project_id)) {
        // Insert task
        $stmt = $pdo->prepare("INSERT INTO tasks (project_id, title, due_date) VALUES (?, ?, ?)");
        $stmt->execute([$project_id, $title, $due_date]);

        // Get ID and notify
        $task_id = $pdo->lastInsertId();
        $safe_title = htmlspecialchars($title);

        addNotification(
            $pdo,
            $user_id,
            "📝 New task added: <strong>$safe_title</strong>",
            "tasks.php#task-$task_id"
        );

        header("Location: tasks.php");
        exit;
    }
}

// Fetch all projects for this user
$stmt = $pdo->prepare("SELECT * FROM projects WHERE user_id = ?");
$stmt->execute([$user_id]);
$projects = $stmt->fetchAll();

// Fetch all tasks linked to user's projects
$stmt = $pdo->prepare("
    SELECT t.*, p.title AS project_title 
    FROM tasks t 
    JOIN projects p ON t.project_id = p.id 
    WHERE p.user_id = ? 
    ORDER BY t.created_at DESC
");
$stmt->execute([$user_id]);
$tasks = $stmt->fetchAll();
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Tasks - Focal</title>
  <style>
    :root {
      --bg-primary: #fefcf8;
      --bg-secondary: #ffffff;
      --bg-card: #ffffff;
      --bg-hover: #f8f6f2;
      --border-color: #e8e4df;
      --text-primary: #2d2d2d;
      --text-secondary: #6b6b6b;
      --text-muted: #9a9a9a;
      --accent-primary: #ff6314;
      --accent-secondary: #5296dd;
      --accent-hover: #ff5722;
      --success: #22c55e;
      --warning: #f59e0b;
      --pending: #94a3b8;
      --gradient: linear-gradient(135deg, #ff6314 0%, #5296dd 100%);
      --warm-orange: #ffaa7a;
      --warm-yellow: #ffeaa7;
      --warm-cream: #fff8f0;
      --shadow-soft: 0 2px 8px rgba(255, 99, 20, 0.08);
      --shadow-hover: 0 8px 24px rgba(255, 99, 20, 0.15);
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Helvetica Neue', sans-serif;
      background: linear-gradient(135deg, var(--warm-cream) 0%, var(--bg-primary) 100%);
      color: var(--text-primary);
      line-height: 1.6;
      min-height: 100vh;
    }

    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 16px;
    }

    /* Header */
    .header {
      background: rgba(255, 255, 255, 0.95);
      border-bottom: 1px solid var(--border-color);
      padding: 16px 0;
      position: sticky;
      top: 0;
      z-index: 100;
      backdrop-filter: blur(20px);
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
    }

    .header-content {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .logo {
      font-size: 24px;
      font-weight: 700;
      background: var(--gradient);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
      text-decoration: none;
    }

    .breadcrumb {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 14px;
      color: var(--text-secondary);
    }

    .breadcrumb a {
      color: var(--accent-secondary);
      text-decoration: none;
    }

    .breadcrumb a:hover {
      text-decoration: underline;
    }

    .user-info {
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .user-avatar {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      background: var(--gradient);
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 600;
      font-size: 14px;
    }

    /* Main Content */
    .main-content {
      display: grid;
      grid-template-columns: 400px 1fr;
      gap: 24px;
      padding: 24px 0;
    }

    .sidebar {
      position: sticky;
      top: 88px;
      height: fit-content;
    }

    .content {
      display: flex;
      flex-direction: column;
      gap: 20px;
    }

    /* Cards */
    .card {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: 12px;
      overflow: hidden;
      transition: all 0.3s ease;
      box-shadow: var(--shadow-soft);
    }

    .card:hover {
      border-color: var(--warm-orange);
      box-shadow: var(--shadow-hover);
      transform: translateY(-1px);
    }

    .card-header {
      padding: 20px 24px;
      border-bottom: 1px solid var(--border-color);
      display: flex;
      align-items: center;
      justify-content: between;
      background: var(--warm-cream);
    }

    .card-title {
      font-size: 20px;
      font-weight: 600;
      color: var(--text-primary);
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .card-content {
      padding: 24px;
    }

    /* Form Styles */
    .form-group {
      margin-bottom: 20px;
    }

    .form-label {
      display: block;
      font-weight: 600;
      color: var(--text-primary);
      margin-bottom: 8px;
      font-size: 14px;
    }

    .form-input,
    .form-select {
      width: 100%;
      padding: 12px 16px;
      border: 2px solid var(--border-color);
      border-radius: 8px;
      font-size: 14px;
      background: var(--bg-secondary);
      color: var(--text-primary);
      transition: all 0.2s ease;
    }

    .form-input:focus,
    .form-select:focus {
      outline: none;
      border-color: var(--accent-primary);
      box-shadow: 0 0 0 3px rgba(255, 99, 20, 0.1);
    }

    .form-button {
      background: var(--gradient);
      color: white;
      border: none;
      padding: 14px 24px;
      border-radius: 8px;
      font-weight: 600;
      font-size: 14px;
      cursor: pointer;
      transition: all 0.2s ease;
      box-shadow: 0 2px 8px rgba(255, 99, 20, 0.3);
      width: 100%;
    }

    .form-button:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(255, 99, 20, 0.4);
    }

    /* Task List */
    .task-grid {
      display: flex;
      flex-direction: column;
      gap: 16px;
    }

    .task-card {
      background: var(--bg-card);
      border: 1px solid var(--border-color);
      border-radius: 12px;
      padding: 20px;
      transition: all 0.2s ease;
      box-shadow: var(--shadow-soft);
      position: relative;
    }

    .task-card:hover {
      transform: translateY(-2px);
      box-shadow: var(--shadow-hover);
    }

    .task-card::before {
      content: '';
      position: absolute;
      left: 0;
      top: 0;
      bottom: 0;
      width: 4px;
      border-radius: 12px 0 0 12px;
    }

    .task-card.status-pending::before {
      background: var(--pending);
    }

    .task-card.status-in_progress::before {
      background: var(--warning);
    }

    .task-card.status-completed::before {
      background: var(--success);
    }

    .task-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 12px;
    }

    .task-title {
      font-size: 18px;
      font-weight: 600;
      color: var(--text-primary);
      margin-bottom: 4px;
    }

    .task-project {
      font-size: 14px;
      color: var(--accent-secondary);
      font-weight: 500;
    }

    .task-meta {
      display: flex;
      flex-wrap: wrap;
      gap: 16px;
      margin-bottom: 16px;
      font-size: 14px;
      color: var(--text-secondary);
    }

    .task-meta-item {
      display: flex;
      align-items: center;
      gap: 4px;
    }

    .task-actions {
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .status-select {
      padding: 8px 12px;
      border: 1px solid var(--border-color);
      border-radius: 6px;
      background: var(--bg-secondary);
      font-size: 14px;
      cursor: pointer;
      transition: all 0.2s ease;
    }

    .status-select:focus {
      outline: none;
      border-color: var(--accent-primary);
    }

    .status-badge {
      padding: 4px 12px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .status-badge.pending {
      background: rgba(148, 163, 184, 0.2);
      color: var(--pending);
    }

    .status-badge.in_progress {
      background: rgba(245, 158, 11, 0.2);
      color: var(--warning);
    }

    .status-badge.completed {
      background: rgba(34, 197, 94, 0.2);
      color: var(--success);
    }

    /* Empty State */
    .empty-state {
      text-align: center;
      padding: 60px 20px;
      color: var(--text-muted);
    }

    .empty-state-icon {
      font-size: 64px;
      margin-bottom: 16px;
      opacity: 0.5;
    }

    .empty-state h3 {
      font-size: 20px;
      margin-bottom: 8px;
      color: var(--text-secondary);
    }

    .empty-state p {
      font-size: 16px;
    }

    /* Quick Stats */
    .quick-stats {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 16px;
      margin-bottom: 24px;
    }

    .stat-item {
      background: var(--warm-cream);
      padding: 16px;
      border-radius: 8px;
      text-align: center;
      border: 1px solid var(--border-color);
    }

    .stat-number {
      font-size: 24px;
      font-weight: 700;
      background: var(--gradient);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }

    .stat-label {
      font-size: 12px;
      color: var(--text-secondary);
      text-transform: uppercase;
      font-weight: 600;
      letter-spacing: 0.5px;
      margin-top: 4px;
    }

    /* Responsive */
    @media (max-width: 768px) {
      .main-content {
        grid-template-columns: 1fr;
      }
      
      .sidebar {
        position: static;
        order: 2;
      }
      
      .content {
        order: 1;
      }

      .quick-stats {
        grid-template-columns: repeat(2, 1fr);
      }

      .task-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 8px;
      }

      .task-actions {
        width: 100%;
        justify-content: flex-end;
      }
    }

    @media (max-width: 480px) {
      .container {
        padding: 0 12px;
      }
      
      .quick-stats {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>
  <header class="header">
    <div class="container">
      <div class="header-content">
        <a href="home.php" class="logo">Focal</a>
        <div class="breadcrumb">
          <a href="home.php">Dashboard</a>
          <span>→</span>
          <span>Tasks</span>
        </div>
        <div class="user-info">
          <div class="user-avatar"><?= strtoupper(substr($name, 0, 1)) ?></div>
        </div>
      </div>
    </div>
  </header>

  <div class="container">
    <div class="main-content">
      <aside class="sidebar">
        <!-- Create Task Form -->
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">📝 Create New Task</h3>
          </div>
          <div class="card-content">
            <form method="POST">
              <div class="form-group">
                <label class="form-label">Project</label>
                <select name="project_id" class="form-select" required>
                  <option value="">-- Select Project --</option>
                  <?php if (count($projects) > 0): ?>
                    <?php foreach ($projects as $project): ?>
                      <option value="<?= $project['id'] ?>"><?= htmlspecialchars($project['title']) ?></option>
                    <?php endforeach; ?>
                  <?php else: ?>
                    <option disabled>No projects found</option>
                  <?php endif; ?>
                </select>
              </div>

              <div class="form-group">
                <label class="form-label">Task Title</label>
                <input type="text" name="title" class="form-input" placeholder="Enter task title..." required>
              </div>

              <div class="form-group">
                <label class="form-label">Due Date</label>
                <input type="date" name="due_date" class="form-input">
              </div>

              <button type="submit" class="form-button">Create Task</button>
            </form>
          </div>
        </div>

        <!-- Task Stats -->
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">📊 Task Overview</h3>
          </div>
          <div class="card-content">
            <div class="quick-stats">
              <?php
              $pending_count = array_filter($tasks, fn($t) => $t['status'] === 'pending');
              $progress_count = array_filter($tasks, fn($t) => $t['status'] === 'in_progress');
              $completed_count = array_filter($tasks, fn($t) => $t['status'] === 'completed');
              ?>
              <div class="stat-item">
                <div class="stat-number"><?= count($pending_count) ?></div>
                <div class="stat-label">Pending</div>
              </div>
              <div class="stat-item">
                <div class="stat-number"><?= count($progress_count) ?></div>
                <div class="stat-label">In Progress</div>
              </div>
              <div class="stat-item">
                <div class="stat-number"><?= count($completed_count) ?></div>
                <div class="stat-label">Completed</div>
              </div>
            </div>
          </div>
        </div>
      </aside>

      <main class="content">
        <!-- Page Header -->
        <div class="card">
          <div class="card-header">
            <h2 class="card-title">✅ All Tasks (<?= count($tasks) ?>)</h2>
          </div>
        </div>

        <!-- Task List -->
        <div class="task-grid">
          <?php if (count($tasks) > 0): ?>
            <?php foreach ($tasks as $task): ?>
              <div class="task-card status-<?= $task['status'] ?>">
                <div class="task-header">
                  <div>
                    <h3 class="task-title"><?= htmlspecialchars($task['title']) ?></h3>
                    <div class="task-project">📁 <?= htmlspecialchars($task['project_title']) ?></div>
                  </div>
                  <div class="task-actions">
                    <span class="status-badge <?= $task['status'] ?>">
                      <?= ucfirst(str_replace('_', ' ', $task['status'])) ?>
                    </span>
                  </div>
                </div>

                <div class="task-meta">
                  <div class="task-meta-item">
                    <span>📅</span>
                    <span>Due: <?= $task['due_date'] ? date('M j, Y', strtotime($task['due_date'])) : 'No deadline' ?></span>
                  </div>
                  <div class="task-meta-item">
                    <span>🕒</span>
                    <span>Created: <?= date('M j, Y', strtotime($task['created_at'])) ?></span>
                  </div>
                </div>

                <div class="task-actions">
                  <form method="POST" action="../api/update_task_status.php" style="display: inline;">
                    <input type="hidden" name="task_id" value="<?= $task['id'] ?>">
                    <select name="status" class="status-select" onchange="this.form.submit()">
                      <option value="pending" <?= $task['status'] === 'pending' ? 'selected' : '' ?>>Pending</option>
                      <option value="in_progress" <?= $task['status'] === 'in_progress' ? 'selected' : '' ?>>In Progress</option>
                      <option value="completed" <?= $task['status'] === 'completed' ? 'selected' : '' ?>>Completed</option>
                    </select>
                  </form>
                </div>
              </div>
            <?php endforeach; ?>
          <?php else: ?>
            <div class="card">
              <div class="card-content">
                <div class="empty-state">
                  <div class="empty-state-icon">📝</div>
                  <h3>No tasks yet</h3>
                  <p>Create your first task to get started with project management!</p>
                </div>
              </div>
            </div>
          <?php endif; ?>
        </div>
      </main>
    </div>
  </div>

  <script>
    // Add loading state to form submission
    document.querySelector('form').addEventListener('submit', function() {
      const button = this.querySelector('.form-button');
      button.textContent = 'Creating...';
      button.disabled = true;
    });

    // Animate task cards on load
    document.addEventListener('DOMContentLoaded', function() {
      const taskCards = document.querySelectorAll('.task-card');
      taskCards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        setTimeout(() => {
          card.style.transition = 'all 0.4s ease';
          card.style.opacity = '1';
          card.style.transform = 'translateY(0)';
        }, index * 100);
      });
    });

    // Add confirmation for status changes
    document.querySelectorAll('.status-select').forEach(select => {
      select.addEventListener('change', function() {
        const taskTitle = this.closest('.task-card').querySelector('.task-title').textContent;
        const newStatus = this.value.replace('_', ' ');
        if (confirm(`Change "${taskTitle}" status to "${newStatus}"?`)) {
          this.form.submit();
        } else {
          // Reset to previous value if cancelled
          this.selectedIndex = Array.from(this.options).findIndex(option => 
            option.hasAttribute('selected')
          );
        }
      });
    });
  </script>
</body>
</html>