<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);



session_start();
require_once '../vendor/autoload.php'; // Or your manual include
require_once '../config/db.php';

$client = new Google_Client();
$client->setClientId('803196122165-tvil3i27lu9k3rv6f1044oeccncr6656.apps.googleusercontent.com');
$client->setClientSecret('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');
$client->setRedirectUri('https://focal.forthestartups.com/auth/google-callback.php');

$client->addScope("email");
$client->addScope("profile");

if (isset($_GET['code'])) {
    $client->authenticate($_GET['code']);
    $token = $client->getAccessToken();
    $client->setAccessToken($token);

    $oauth = new Google_Service_Oauth2($client);
    $google_user = $oauth->userinfo->get();

    // Check if user exists or create
    $email = $google_user->email;
    $name = $google_user->name;

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user) {
        // Insert new user
        $stmt = $pdo->prepare("INSERT INTO users (name, email) VALUES (?, ?)");
        $stmt->execute([$name, $email]);
        $user_id = $pdo->lastInsertId();
    } else {
        $user_id = $user['id'];
    }

    $_SESSION['user_id'] = $user_id;
    $_SESSION['name'] = $name;

    header("Location: ../dashboard/home.php");
    exit;
} else {
    echo "Authentication failed.";
}
