<?php
include '../includes/auth.php';
require_once '../config/db.php';

// Ensure UTF-8 encoding for the database connection
$pdo->exec("SET NAMES 'utf8mb4'");

$user_id = $_SESSION['user_id'];
// Use the actual emoji directly for the notification message
$message = "🔔 Test notification at " . date('H:i:s');

// Prepare and execute the query to insert the notification
$stmt = $pdo->prepare("INSERT INTO notifications (user_id, message) VALUES (?, ?)");
$stmt->execute([$user_id, $message]);

// Redirect to the notifications page
header("Location: ../notifications/index.php");
exit;
?>