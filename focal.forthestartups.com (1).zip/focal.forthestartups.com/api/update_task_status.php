<?php
include '../includes/auth.php';
require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $task_id = $_POST['task_id'] ?? null;
    $new_status = $_POST['status'] ?? null;

    $allowed = ['pending', 'in_progress', 'completed'];

    if ($task_id && in_array($new_status, $allowed)) {
        $stmt = $pdo->prepare("UPDATE tasks SET status = ? WHERE id = ?");
        $stmt->execute([$new_status, $task_id]);
    }
}

header("Location: ../dashboard/tasks.php");
exit;
?>
