<?php
session_start();
require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['name']);
    $email    = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Check if email already exists
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        echo "Email already registered. <a href='../register.php'>Try again</a>";
        exit;
    }

    // Insert new user
    $stmt = $pdo->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
    if ($stmt->execute([$name, $email, $password])) {
        $user_id = $pdo->lastInsertId();

        // Auto-login
        $_SESSION['user_id'] = $user_id;
        $_SESSION['name'] = $name;

        header('Location: ../dashboard/home.php');
        exit;
    } else {
        echo "Registration failed. <a href='../register.php'>Try again</a>";
    }
}
?>
