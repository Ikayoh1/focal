<?php
$host = 'localhost';
$dbname = 'forthest_focal_db';
$username = 'forthest_fuser';
$password = 'vJ75l%4p#4a4';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// ✅ Notification function here
function addNotification($pdo, $user_id, $message, $link = null) {
    if (empty(trim($message))) {
        return; // Don't insert blank messages
    }

    $stmt = $pdo->prepare("INSERT INTO notifications (user_id, message, link) VALUES (?, ?, ?)");
    $stmt->execute([$user_id, $message, $link]);
}
?>
